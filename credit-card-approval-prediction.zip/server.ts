/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

import {
  createUser,
  findUserByEmail,
  findUserById,
  updateUserProfile,
  changeUserPassword,
  deleteUserAccount,
  deleteUserByAdmin,
  getAllUsers,
  getAllPredictions,
  createPredictionRecord,
  deletePredictionRecord,
  getMetadata,
  getAllLogs,
  writeSystemLog,
  createContactMessage,
  getContactMessages
} from "./src/lib/database";

import { predictApproval, retrainPipeline } from "./src/lib/mlEngine";
import { PredictionInput, PredictionResult } from "./src/types";

// Initialize Gemini Client
let ai: GoogleGenAI | null = null;
const geminiApiKey = process.env.GEMINI_API_KEY;

if (geminiApiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey: geminiApiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    console.log("Gemini AI Client initialized successfully.");
  } catch (error) {
    console.error("Failed to initialize Gemini AI Client:", error);
  }
} else {
  console.warn("GEMINI_API_KEY environment variable is not set. Gemini AI explanations will use standard backup mode.");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parser limit for rich uploads or inputs
  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ extended: true, limit: "10mb" }));

  // Request logs middleware
  app.use((req, res, next) => {
    // Avoid spamming log file for polling endpoints, only log primary APIs
    if (req.path.startsWith("/api/") && !req.path.includes("/logs") && !req.path.includes("/me")) {
      console.log(`[API REQUEST] ${req.method} ${req.path}`);
    }
    next();
  });

  // Simple tokenless header-based Auth Middleware
  // In our iframe environment, standard Bearer tokens in headers are highly secure and robust.
  const authMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ error: "Unauthorized access" });
      return;
    }
    const token = authHeader.split(" ")[1];
    const user = findUserById(token);
    if (!user) {
      res.status(401).json({ error: "Invalid session token" });
      return;
    }
    (req as any).user = user;
    next();
  };

  const adminMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = (req as any).user;
    if (!user || user.role !== "admin") {
      res.status(403).json({ error: "Access denied. Admin role required." });
      return;
    }
    next();
  };

  // ==========================================
  // AUTHENTICATION ENDPOINTS
  // ==========================================

  app.post("/api/auth/register", (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      res.status(400).json({ error: "Name, email, and password are required fields" });
      return;
    }

    try {
      const existing = findUserByEmail(email);
      if (existing) {
        res.status(400).json({ error: "A user with this email address already exists" });
        return;
      }

      const user = createUser(name, email, password, "user");
      // Return user and set session token as user.id (simplifies auth in iframe)
      res.status(201).json({ token: user.id, user });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Registration failed" });
    }
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "Email and password are required" });
      return;
    }

    try {
      const user = findUserByEmail(email);
      if (!user) {
        res.status(401).json({ error: "Invalid email or password" });
        return;
      }

      const hash = crypto.createHash("sha256").update(password).digest("hex");
      if (user.passwordHash !== hash) {
        res.status(401).json({ error: "Invalid email or password" });
        return;
      }

      writeSystemLog("info", `User logged in successfully: ${user.name}`, user.id);
      res.json({ token: user.id, user });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Login failed" });
    }
  });

  app.get("/api/auth/me", authMiddleware, (req, res) => {
    res.json({ user: (req as any).user });
  });

  app.post("/api/auth/update-profile", authMiddleware, (req, res) => {
    const { name, email } = req.body;
    const user = (req as any).user;
    if (!name || !email) {
      res.status(400).json({ error: "Name and email are required" });
      return;
    }

    try {
      const updated = updateUserProfile(user.id, name, email);
      res.json({ user: updated });
    } catch (err: any) {
      res.status(400).json({ error: err.message || "Failed to update profile" });
    }
  });

  app.post("/api/auth/change-password", authMiddleware, (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const user = (req as any).user;
    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: "Current and new passwords are required" });
      return;
    }

    try {
      const currentHash = crypto.createHash("sha256").update(currentPassword).digest("hex");
      if (user.passwordHash !== currentHash) {
        res.status(400).json({ error: "Incorrect current password" });
        return;
      }

      changeUserPassword(user.id, newPassword);
      res.json({ success: true, message: "Password updated successfully" });
    } catch (err: any) {
      res.status(400).json({ error: err.message || "Failed to update password" });
    }
  });

  app.post("/api/auth/delete-account", authMiddleware, (req, res) => {
    const user = (req as any).user;
    try {
      deleteUserAccount(user.id);
      res.json({ success: true, message: "Account deleted successfully" });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to delete account" });
    }
  });

  // ==========================================
  // PREDICTIONS & MACHINE LEARNING PIPELINE
  // ==========================================

  app.post("/api/prediction/predict", authMiddleware, async (req, res) => {
    const input = req.body as PredictionInput;
    const user = (req as any).user;

    // Strict input validation
    if (
      !input.fullName ||
      !input.email ||
      !input.gender ||
      typeof input.age !== "number" ||
      !input.maritalStatus ||
      !input.education ||
      !input.employmentStatus ||
      !input.occupation ||
      typeof input.yearsOfEmployment !== "number" ||
      typeof input.annualIncome !== "number" ||
      typeof input.creditScore !== "number" ||
      !input.existingLoans ||
      typeof input.loanAmount !== "number" ||
      typeof input.monthlyEMI !== "number" ||
      !input.propertyOwnership ||
      typeof input.numDependents !== "number" ||
      typeof input.bankBalance !== "number"
    ) {
      res.status(400).json({ error: "Validation failed. Please verify that all 17 fields are provided correctly." });
      return;
    }

    try {
      // 1. Run local mathematical ML prediction
      const mlOutput = predictApproval(input);

      // 2. Generate AI Explanation & Recommendations (Server-Side Gemini API with fallback)
      let aiExplanation = "";
      let recommendation = "";

      const approvalWord = mlOutput.approved ? "APPROVED" : "REJECTED";
      const probPercent = Math.round(mlOutput.probability * 100);

      const promptText = `
        You are an elite, senior credit risk underwriter and financial AI analyst at a premium commercial bank.
        Analyze the following credit card application and generate a detailed report.
        
        APPLICANT PROFILE:
        - Full Name: ${input.fullName}
        - Age: ${input.age}
        - Education: ${input.education}
        - Employment: ${input.employmentStatus} as ${input.occupation} (${input.yearsOfEmployment} years)
        - Annual Income: $${input.annualIncome.toLocaleString()}
        - Credit Score: ${input.creditScore} (Scale: 300 - 850)
        - Existing Loans: ${input.existingLoans}
        - Requested Loan Amount: $${input.loanAmount.toLocaleString()}
        - Monthly Debt EMI Obligation: $${input.monthlyEMI.toLocaleString()}
        - Bank Account Balance: $${input.bankBalance.toLocaleString()}
        - Property Ownership: ${input.propertyOwnership}
        - Dependents: ${input.numDependents}

        MODEL PREDICTION STATUS:
        - Decision: ${approvalWord}
        - Probability of Approval: ${probPercent}%
        - Risk Classification: ${mlOutput.riskLevel} Risk
        - Financial Health Score: ${mlOutput.financialHealthScore}/100

        INSTRUCTIONS:
        Based on the profile above, generate two distinct text sections in your response. Keep them concise, enterprise-grade, highly professional, and tailored strictly to the applicant's profile.

        Section 1: AI Underwriting Explanation (150-200 words max)
        A detailed risk assessment explaining why the model made this decision. Address key strengths (like high credit score, high savings balance, or strong income) and risk factors (like low employment duration, existing debts, or high requested debt ratio). Talk in professional banking underwriting terms.

        Section 2: Recommendation & Financial Roadmap (3-4 bullet points)
        Actionable, high-impact advice. If approved, outline credit limits and credit utilization best practices. If rejected, provide concrete steps to become eligible (e.g., specific debt reduction, credit score targets, or savings targets).

        Separate the two sections with the exact delimiter: "===SECTION_SPLIT==="
        Do not output markdown headers or extra conversational text outside these sections.
      `;

      if (ai) {
        try {
          const geminiResponse = await ai.models.generateContent({
            model: "gemini-3.5-flash",
            contents: promptText,
          });
          const rawText = geminiResponse.text || "";
          
          if (rawText.includes("===SECTION_SPLIT===")) {
            const parts = rawText.split("===SECTION_SPLIT===");
            aiExplanation = parts[0].trim();
            recommendation = parts[1].trim();
          } else {
            // Split by lines if delimiter was omitted
            aiExplanation = rawText.slice(0, Math.floor(rawText.length / 2)).trim();
            recommendation = rawText.slice(Math.floor(rawText.length / 2)).trim();
          }
        } catch (gErr) {
          console.error("Gemini request failed, entering standard fallback:", gErr);
        }
      }

      // 3. Fallback/Standard static generator if Gemini failed or is not available
      if (!aiExplanation || !recommendation) {
        if (mlOutput.approved) {
          aiExplanation = `Credit application underwritten successfully. The applicant exhibits a strong credit score of ${input.creditScore} coupled with a healthy bank balance of $${input.bankBalance.toLocaleString()}. With an annual income of $${input.annualIncome.toLocaleString()} and moderate existing debt, the applicant's debt-to-income (DTI) ratio is highly favorable at ${((input.monthlyEMI * 12 / input.annualIncome) * 100).toFixed(1)}%. Employment history as a ${input.occupation} for ${input.yearsOfEmployment} years provides solid verification of repayment stability.`;
          recommendation = `• Maintain your low credit card utilization (aim for under 30% of your limit).\n• Set up automatic monthly payments to preserve your pristine on-time record.\n• Avoid opening multiple new credit inquiries within the next six months.\n• Regularly review credit statements for unexpected billing anomalies.`;
        } else {
          aiExplanation = `Credit application declined due to risk variance. The primary risk vectors identified include an elevated credit risk score of ${input.creditScore} and insufficient capital reserves ($${input.bankBalance.toLocaleString()}). The debt-to-income (DTI) ratio of ${((input.monthlyEMI * 12 / (input.annualIncome || 1)) * 100).toFixed(1)}% exceeds the maximum recommended tier for this credit limit. Additionally, employment stability or occupation profile does not offset the existing debt exposure.`;
          recommendation = `• Focus on raising your credit score to at least 680 by correcting any report errors and paying off card balances.\n• Reduce your monthly debt obligation (target an EMI-to-income ratio below 30%).\n• Build a minimum cash reserve of three to six months of expenses in your bank account.\n• Reapply in 90 to 180 days after establishing a consistent payment history.`;
        }
      }

      const finalResult: PredictionResult = {
        ...mlOutput,
        aiExplanation,
        recommendation,
      };

      // 4. Save to Database history
      const savedRecord = createPredictionRecord(user.id, input, finalResult);
      res.json(savedRecord);
    } catch (err: any) {
      console.error("Prediction endpoint failed:", err);
      res.status(500).json({ error: err.message || "An error occurred during prediction processing." });
    }
  });

  // Fetch prediction logs with sorting, search, and pagination!
  app.get("/api/prediction/history", authMiddleware, (req, res) => {
    const user = (req as any).user;
    const { search, resultFilter, riskFilter, sortField, sortOrder, page, limit } = req.query;

    try {
      let records = getAllPredictions();

      // Non-admins can only see their own predictions
      if (user.role !== "admin") {
        records = records.filter((r) => r.userId === user.id);
      }

      // 1. Search filter (applicant name or credit score)
      if (search) {
        const query = String(search).toLowerCase();
        records = records.filter(
          (r) =>
            r.applicantName.toLowerCase().includes(query) ||
            r.id.toLowerCase().includes(query) ||
            String(r.creditScore).includes(query)
        );
      }

      // 2. Result Filter (Approved vs Rejected)
      if (resultFilter && resultFilter !== "all") {
        const approvedBool = resultFilter === "approved";
        records = records.filter((r) => r.result.approved === approvedBool);
      }

      // 3. Risk Filter
      if (riskFilter && riskFilter !== "all") {
        records = records.filter((r) => r.result.riskLevel.toLowerCase() === String(riskFilter).toLowerCase());
      }

      // 4. Sort
      const field = String(sortField || "createdAt");
      const order = String(sortOrder || "desc");

      records.sort((a: any, b: any) => {
        let valA = a[field] !== undefined ? a[field] : a.result[field];
        let valB = b[field] !== undefined ? b[field] : b.result[field];

        // Handle nested fields
        if (field === "income") {
          valA = a.income;
          valB = b.income;
        }

        if (valA === undefined || valB === undefined) return 0;

        if (typeof valA === "string") {
          return order === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
        } else {
          return order === "asc" ? valA - valB : valB - valA;
        }
      });

      // 5. Paginate
      const pageNum = parseInt(String(page || "1"), 10);
      const limitNum = parseInt(String(limit || "10"), 10);
      const totalRecords = records.length;
      const totalPages = Math.ceil(totalRecords / limitNum);

      const paginatedRecords = records.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        records: paginatedRecords,
        pagination: {
          total: totalRecords,
          pages: totalPages,
          currentPage: pageNum,
          limit: limitNum,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to load prediction history" });
    }
  });

  app.delete("/api/prediction/:id", authMiddleware, (req, res) => {
    const { id } = req.params;
    const user = (req as any).user;

    try {
      const records = getAllPredictions();
      const record = records.find((r) => r.id === id);

      if (!record) {
        res.status(404).json({ error: "Prediction record not found" });
        return;
      }

      // Gatekeeping: Users can only delete their own. Admins can delete any.
      if (user.role !== "admin" && record.userId !== user.id) {
        res.status(403).json({ error: "Access denied" });
        return;
      }

      deletePredictionRecord(id);
      res.json({ success: true, message: "Prediction deleted successfully" });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to delete prediction" });
    }
  });

  // ==========================================
  // ANALYTICS ENDPOINTS
  // ==========================================

  app.get("/api/analytics/dashboard", authMiddleware, (req, res) => {
    const user = (req as any).user;

    try {
      let records = getAllPredictions();

      // Normal users only see their own statistics, admin sees system-wide statistics
      if (user.role !== "admin") {
        records = records.filter((r) => r.userId === user.id);
      }

      // 1. Core Summary Cards
      const totalPredictions = records.length;
      const approvals = records.filter((r) => r.result.approved).length;
      const rejections = totalPredictions - approvals;
      const approvalRate = totalPredictions > 0 ? approvals / totalPredictions : 0;

      // Avg credit score
      const avgCreditScore =
        totalPredictions > 0
          ? Math.round(records.reduce((sum, r) => sum + r.creditScore, 0) / totalPredictions)
          : 0;

      // 2. Risk Distribution
      const riskDistribution = { Low: 0, Medium: 0, High: 0, Critical: 0 };
      records.forEach((r) => {
        const rl = r.result.riskLevel;
        if (rl in riskDistribution) {
          riskDistribution[rl as keyof typeof riskDistribution]++;
        }
      });

      // 3. Credit Score Brackets Distribution
      // Poor: 300-579, Fair: 580-669, Good: 670-739, Very Good: 740-799, Excellent: 800-850
      const creditScoreDistribution = {
        Poor: 0,
        Fair: 0,
        Good: 0,
        "Very Good": 0,
        Excellent: 0,
      };
      records.forEach((r) => {
        const cs = r.creditScore;
        if (cs < 580) creditScoreDistribution.Poor++;
        else if (cs < 670) creditScoreDistribution.Fair++;
        else if (cs < 740) creditScoreDistribution.Good++;
        else if (cs < 800) creditScoreDistribution["Very Good"]++;
        else creditScoreDistribution.Excellent++;
      });

      // 4. Monthly prediction counts
      const monthlyPredictions: Record<string, { total: number; approved: number; rejected: number }> = {};
      records.forEach((r) => {
        // Date format: "YYYY-MM"
        const dateObj = new Date(r.createdAt);
        const key = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, "0")}`;
        if (!monthlyPredictions[key]) {
          monthlyPredictions[key] = { total: 0, approved: 0, rejected: 0 };
        }
        monthlyPredictions[key].total++;
        if (r.result.approved) monthlyPredictions[key].approved++;
        else monthlyPredictions[key].rejected++;
      });

      const monthlyChartData = Object.entries(monthlyPredictions)
        .map(([month, data]) => ({
          month,
          total: data.total,
          approved: data.approved,
          rejected: data.rejected,
        }))
        .sort((a, b) => a.month.localeCompare(b.month))
        .slice(-12); // Last 12 months

      // 5. Income Brackets
      const incomeDistribution = {
        "< $30K": 0,
        "$30K - $60K": 0,
        "$60K - $90K": 0,
        "$90K - $120K": 0,
        "> $120K": 0,
      };
      records.forEach((r) => {
        const inc = r.income;
        if (inc < 30000) incomeDistribution["< $30K"]++;
        else if (inc < 60000) incomeDistribution["$30K - $60K"]++;
        else if (inc < 90000) incomeDistribution["$60K - $90K"]++;
        else if (inc < 120000) incomeDistribution["$90K - $120K"]++;
        else incomeDistribution["> $120K"]++;
      });

      // Load active ML model metrics
      const mlMetadata = getMetadata();

      res.json({
        summary: {
          totalPredictions,
          approvals,
          rejections,
          approvalRate,
          avgCreditScore,
        },
        riskDistribution: Object.entries(riskDistribution).map(([name, value]) => ({ name, value })),
        creditScoreDistribution: Object.entries(creditScoreDistribution).map(([name, value]) => ({ name, value })),
        incomeDistribution: Object.entries(incomeDistribution).map(([name, value]) => ({ name, value })),
        monthlyChartData,
        mlMetadata,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to load analytics dashboard data" });
    }
  });

  // ==========================================
  // ADMIN CONTROL ENDPOINTS
  // ==========================================

  app.get("/api/admin/users", authMiddleware, adminMiddleware, (req, res) => {
    try {
      const users = getAllUsers().map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        createdAt: u.createdAt,
      }));
      res.json(users);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to fetch user list" });
    }
  });

  app.delete("/api/admin/users/:id", authMiddleware, adminMiddleware, (req, res) => {
    const { id } = req.params;
    if (id === "usr_admin") {
      res.status(400).json({ error: "Super Admin account cannot be deleted" });
      return;
    }

    try {
      deleteUserByAdmin(id);
      res.json({ success: true, message: "User account deleted successfully" });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to delete user" });
    }
  });

  app.get("/api/admin/logs", authMiddleware, adminMiddleware, (req, res) => {
    try {
      const logs = getAllLogs().sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, 100);
      res.json(logs);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to fetch system logs" });
    }
  });

  app.get("/api/admin/contacts", authMiddleware, adminMiddleware, (req, res) => {
    try {
      const msgs = getContactMessages().sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      res.json(msgs);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to fetch contact inquiries" });
    }
  });

  app.post("/api/admin/retrain", authMiddleware, adminMiddleware, (req, res) => {
    const user = (req as any).user;

    try {
      const updatedMetadata = retrainPipeline();
      writeSystemLog("info", `Machine Learning Model pipeline retrained manually. Activated best: ${updatedMetadata.activeModel}`, user.id);
      res.json({ success: true, message: "Model retrained and optimized successfully.", metadata: updatedMetadata });
    } catch (err: any) {
      console.error("Retraining failed:", err);
      res.status(500).json({ error: "Failed to retrain ML pipeline" });
    }
  });

  // ==========================================
  // PUBLIC CONTACT ENDPOINT
  // ==========================================

  app.post("/api/contact", (req, res) => {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
      res.status(400).json({ error: "All fields are required" });
      return;
    }

    try {
      createContactMessage(name, email, subject, message);
      res.json({ success: true, message: "Thank you! Your message was sent successfully." });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to process inquiry" });
    }
  });

  // ==========================================
  // VITE DEV SERVER / PROD HANDLER
  // ==========================================

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Mounted Vite dev server middleware.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving production static files from dist.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express application server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start application server:", err);
});
