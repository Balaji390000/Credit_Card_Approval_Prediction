/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: "user" | "admin";
  createdAt: string;
}

export interface PredictionInput {
  fullName: string;
  email: string;
  gender: string;
  age: number;
  maritalStatus: string;
  education: string;
  employmentStatus: string;
  occupation: string;
  yearsOfEmployment: number;
  annualIncome: number;
  creditScore: number;
  existingLoans: string;
  loanAmount: number;
  monthlyEMI: number;
  propertyOwnership: string;
  numDependents: number;
  bankBalance: number;
}

export interface PredictionResult {
  approved: boolean;
  probability: number;
  confidenceScore: number;
  riskLevel: "Low" | "Medium" | "High" | "Critical";
  aiExplanation: string;
  recommendation: string;
  financialHealthScore: number;
}

export interface PredictionRecord {
  id: string;
  userId: string;
  applicantName: string;
  creditScore: number;
  income: number;
  createdAt: string;
  input: PredictionInput;
  result: PredictionResult;
}

export interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  confusionMatrix: number[][]; // [[TN, FP], [FN, TP]]
  rocCurve: { fpr: number; tpr: number }[];
  featureImportance: { feature: string; importance: number }[];
}

export interface RetrainingMetadata {
  trainedAt: string;
  activeModel: string;
  datasetSize: number;
  modelComparison: Record<string, ModelMetrics>;
}

export interface SystemLog {
  id: string;
  timestamp: string;
  level: "info" | "warn" | "error";
  message: string;
  userId?: string;
  ip?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}
