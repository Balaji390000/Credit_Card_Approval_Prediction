/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Search,
  Filter,
  ArrowUpDown,
  Trash2,
  Download,
  Printer,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  X,
  FileSpreadsheet,
  AlertCircle,
  FileText,
  Shield,
  Activity
} from "lucide-react";
import { apiFetch } from "../lib/api";
import { PredictionRecord } from "../types";

interface HistoryViewProps {
  onSelectReport: (record: PredictionRecord) => void;
  // If we open a local drawer, we can also bind it
}

export default function HistoryView({ onSelectReport }: HistoryViewProps) {
  const [records, setRecords] = useState<PredictionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Search & Filter State
  const [search, setSearch] = useState("");
  const [resultFilter, setResultFilter] = useState("all");
  const [riskFilter, setRiskFilter] = useState("all");
  const [sortField, setSortField] = useState("createdAt");
  const [sortOrder, setSortOrder] = useState("desc");
  
  // Pagination State
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  const limit = 10;

  // Drawer / Detailed View State
  const [selectedRecord, setSelectedRecord] = useState<PredictionRecord | null>(null);

  // Load predictions
  const fetchRecords = async () => {
    setLoading(true);
    setError("");
    try {
      const queryParams = new URLSearchParams({
        search,
        resultFilter,
        riskFilter,
        sortField,
        sortOrder,
        page: String(page),
        limit: String(limit),
      });

      const response = await apiFetch(`/api/prediction/history?${queryParams.toString()}`);
      setRecords(response.records || []);
      setTotalPages(response.pagination.pages || 1);
      setTotalRecords(response.pagination.total || 0);
    } catch (err: any) {
      setError(err.message || "Failed to load prediction logs");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, [search, resultFilter, riskFilter, sortField, sortOrder, page]);

  // Handle Sort Toggle
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "desc" ? "asc" : "desc");
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
    setPage(1); // Reset page to 1
  };

  // Delete prediction
  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this prediction audit log permanently? This action is irreversible.")) {
      return;
    }

    try {
      await apiFetch(`/api/prediction/${id}`, { method: "DELETE" });
      if (selectedRecord && selectedRecord.id === id) {
        setSelectedRecord(null);
      }
      fetchRecords(); // Refresh list
    } catch (err: any) {
      alert(err.message || "Failed to delete record");
    }
  };

  // Export to CSV
  const handleExportCSV = () => {
    if (records.length === 0) {
      alert("No records available to export.");
      return;
    }

    const headers = [
      "Prediction ID",
      "Date",
      "Applicant Name",
      "Email",
      "FICO Credit Score",
      "Annual Income",
      "Approval Status",
      "Probability",
      "Risk Level",
      "Financial Health Score",
    ];

    const rows = records.map((r) => [
      r.id,
      new Date(r.createdAt).toISOString(),
      r.applicantName,
      r.input.email,
      r.creditScore,
      r.income,
      r.result.approved ? "APPROVED" : "REJECTED",
      Math.round(r.result.probability * 100) + "%",
      r.result.riskLevel,
      r.result.financialHealthScore,
    ]);

    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((e) => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))].join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Credit_Prediction_Export_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export to Printable Report / PDF Trigger
  const handlePrintPDF = (record: PredictionRecord) => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("Popup blocker prevented launching printable report.");
      return;
    }

    const input = record.input;
    const result = record.result;

    printWindow.document.write(`
      <html>
        <head>
          <title>ApexRisk Underwriting Audit - ${record.id}</title>
          <style>
            body { font-family: 'Helvetica Neue', Arial, sans-serif; padding: 40px; color: #333; line-height: 1.6; }
            .header { border-bottom: 2px solid #0284c7; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .logo { font-size: 24px; font-weight: bold; color: #0c4a6e; }
            .doc-type { text-transform: uppercase; font-size: 10px; font-family: monospace; background: #e0effe; color: #0284c7; padding: 4px 8px; border-radius: 4px; }
            .grid { display: grid; grid-template-cols: repeat(2, 1fr); gap: 20px; margin-bottom: 30px; }
            .card { background: #f8fafc; border: 1px solid #e2e8f0; padding: 20px; border-radius: 8px; }
            .card-title { text-transform: uppercase; font-size: 10px; font-weight: bold; color: #64748b; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 12px; }
            .metric { display: flex; justify-content: space-between; border-bottom: 1px dashed #e2e8f0; padding: 6px 0; font-size: 12px; }
            .metric:last-child { border-bottom: none; }
            .label { font-weight: bold; color: #475569; }
            .decision { font-size: 32px; font-weight: bold; text-align: center; margin: 40px 0; padding: 15px; border-radius: 8px; }
            .approved { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
            .declined { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
            .narrative { background: #f8fafc; border-left: 4px solid #0284c7; padding: 20px; border-radius: 4px; font-size: 13px; margin-bottom: 30px; }
            .footer { border-top: 1px solid #e2e8f0; padding-top: 20px; margin-top: 50px; text-align: center; font-size: 10px; color: #94a3b8; }
            @media print {
              body { padding: 0; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="logo">ApexRisk Underwriting Report</div>
            <div class="doc-type">OFFICIAL AUDIT REPORT FILE: ${record.id}</div>
          </div>

          <div class="decision ${result.approved ? "approved" : "declined"}">
            DECISION: ${result.approved ? "APPROVED" : "DECLINED"}
            <div style="font-size: 12px; font-weight: normal; margin-top: 6px;">Credit Approval Probability Score: ${Math.round(result.probability * 100)}%</div>
          </div>

          <div class="grid">
            <div class="card">
              <div class="card-title">Applicant Demographics</div>
              <div class="metric"><span class="label">Full Name:</span><span>${input.fullName}</span></div>
              <div class="metric"><span class="label">Email Address:</span><span>${input.email}</span></div>
              <div class="metric"><span class="label">Age / Gender:</span><span>${input.age} Years / ${input.gender}</span></div>
              <div class="metric"><span class="label">Education:</span><span>${input.education}</span></div>
              <div class="metric"><span class="label">Marital Status:</span><span>${input.maritalStatus}</span></div>
              <div class="metric"><span class="label">Dependents:</span><span>${input.numDependents}</span></div>
            </div>

            <div class="card">
              <div class="card-title">Financial Balance Sheet</div>
              <div class="metric"><span class="label">Annual Income:</span><span>$${input.annualIncome.toLocaleString()}</span></div>
              <div class="metric"><span class="label">Liquid Savings:</span><span>$${input.bankBalance.toLocaleString()}</span></div>
              <div class="metric"><span class="label">Occupation:</span><span>${input.occupation}</span></div>
              <div class="metric"><span class="label">Employment Duration:</span><span>${input.yearsOfEmployment} Years (${input.employmentStatus})</span></div>
              <div class="metric"><span class="label">Property Ownership:</span><span>${input.propertyOwnership}</span></div>
              <div class="metric"><span class="label">Financial Health Index:</span><span>${result.financialHealthScore}/100</span></div>
            </div>
          </div>

          <div class="card" style="margin-bottom: 30px;">
            <div class="card-title">Lending Credit Parameters</div>
            <div class="metric"><span class="label">FICO Credit Score:</span><span>${input.creditScore} Points</span></div>
            <div class="metric"><span class="label">Requested Debt Limit:</span><span>$${input.loanAmount.toLocaleString()}</span></div>
            <div class="metric"><span class="label">Monthly Debt Obligation (EMI):</span><span>$${input.monthlyEMI.toLocaleString()}</span></div>
            <div class="metric"><span class="label">Active Loans:</span><span>${input.existingLoans}</span></div>
            <div class="metric"><span class="label">Risk Assessment:</span><span>${result.riskLevel} Risk (Model Conf: ${result.confidenceScore}%)</span></div>
          </div>

          <div class="card-title">Cognitive Underwriting Narrative</div>
          <div class="narrative">
            ${result.aiExplanation.replace(/\n/g, "<br/>")}
          </div>

          <div class="card-title">Actionable Recommendation Roadmap</div>
          <div class="narrative" style="border-left-color: #f59e0b;">
            ${result.recommendation.replace(/\n/g, "<br/>")}
          </div>

          <div class="footer">
            Generated officially on ${new Date(record.createdAt).toLocaleString()} | ApexRisk Underwriting Core Systems v2.4
          </div>

          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="p-6 space-y-6">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-slate-900 tracking-tight">
            Prediction History Logs
          </h1>
          <p className="text-xs text-slate-500 font-light mt-1">
            Browse, search, and export the entire repository of completed credit card underwriting decisions.
          </p>
        </div>

        {/* Global actions */}
        <button
          id="btn-export-csv"
          onClick={handleExportCSV}
          className="px-4 py-2.5 bg-white text-slate-700 hover:bg-slate-50 text-xs font-semibold rounded-xl border border-slate-200 transition-all flex items-center gap-2 cursor-pointer"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Export current list to CSV
        </button>
      </div>

      {/* Search and Filters card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        {/* Search */}
        <div className="md:col-span-5 relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="input-search-history"
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search by applicant name or file transaction ID..."
            className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
          />
        </div>

        {/* Filter Approved / Rejected */}
        <div className="md:col-span-3">
          <select
            id="select-filter-result"
            value={resultFilter}
            onChange={(e) => { setResultFilter(e.target.value); setPage(1); }}
            className="w-full px-3 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 bg-white"
          >
            <option value="all">All Underwriting Decisions</option>
            <option value="approved">Approved Applications</option>
            <option value="rejected">Rejected / Declined Files</option>
          </select>
        </div>

        {/* Filter Risk Level */}
        <div className="md:col-span-3">
          <select
            id="select-filter-risk"
            value={riskFilter}
            onChange={(e) => { setRiskFilter(e.target.value); setPage(1); }}
            className="w-full px-3 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 bg-white"
          >
            <option value="all">All Risk Levels</option>
            <option value="low">Low Risk Tier</option>
            <option value="medium">Medium Risk Tier</option>
            <option value="high">High Risk Tier</option>
            <option value="critical">Critical Risk Tier</option>
          </select>
        </div>
      </div>

      {/* Main logs Table */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-10 h-10 border-4 border-sky-100 border-t-sky-500 rounded-full animate-spin" />
        </div>
      ) : records.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-100 shadow-sm text-slate-400 text-xs font-light">
          No records matching the selected search query and filter rules were found in the database.
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-light">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 uppercase font-mono tracking-wider font-semibold bg-slate-50/50">
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("id")}>
                    ID <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("createdAt")}>
                    Date/Time <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("applicantName")}>
                    Applicant Name <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("creditScore")}>
                    FICO <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("income")}>
                    Income <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("approved")}>
                    Decision <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("probability")}>
                    Score <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-100/30 transition-all" onClick={() => handleSort("riskLevel")}>
                    Risk <ArrowUpDown className="w-3 h-3 inline ml-0.5" />
                  </th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-slate-700">
                {records.map((record) => (
                  <tr key={record.id} className="hover:bg-slate-50/50 transition-all group">
                    <td className="py-3.5 px-4 font-mono text-slate-400 font-medium">{record.id}</td>
                    <td className="py-3.5 px-4 text-slate-500 font-light">
                      {new Date(record.createdAt).toLocaleDateString()} {new Date(record.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900">{record.applicantName}</td>
                    <td className="py-3.5 px-4 font-mono font-medium">{record.creditScore}</td>
                    <td className="py-3.5 px-4 font-mono">${record.income.toLocaleString()}</td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-full font-semibold text-[10px] ${
                          record.result.approved
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
                            : "bg-rose-50 text-rose-700 border border-rose-100"
                        }`}
                      >
                        {record.result.approved ? "APPROVED" : "REJECTED"}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono">{Math.round(record.result.probability * 100)}%</td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-full font-semibold text-[10px] ${
                          record.result.riskLevel === "Low"
                            ? "bg-emerald-50 text-emerald-700"
                            : record.result.riskLevel === "Medium"
                            ? "bg-amber-50 text-amber-700"
                            : "bg-rose-50 text-rose-700"
                        }`}
                      >
                        {record.result.riskLevel}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right flex items-center justify-end gap-1.5 opacity-90 group-hover:opacity-100">
                      {/* Drawer button */}
                      <button
                        id={`btn-view-drawer-${record.id}`}
                        onClick={() => setSelectedRecord(record)}
                        className="p-1 text-slate-400 hover:text-sky-500 hover:bg-sky-50 rounded-lg transition-all cursor-pointer"
                        title="Quick Drawer View"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>

                      {/* PDF Report trigger */}
                      <button
                        id={`btn-print-pdf-${record.id}`}
                        onClick={() => handlePrintPDF(record)}
                        className="p-1 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 rounded-lg transition-all cursor-pointer"
                        title="Print PDF Audit Report"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>

                      {/* Delete */}
                      <button
                        id={`btn-delete-record-${record.id}`}
                        onClick={() => handleDelete(record.id)}
                        className="p-1 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                        title="Delete Record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Footer */}
          <div className="p-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-mono text-slate-500 bg-slate-50/30">
            <div>
              Showing {records.length} of {totalRecords} logged decisions
            </div>

            <div className="flex items-center gap-2">
              <button
                id="btn-prev-page"
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span>Page {page} of {totalPages}</span>
              <button
                id="btn-next-page"
                onClick={() => setPage(Math.min(totalPages, page + 1))}
                disabled={page === totalPages}
                className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 transition-all cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Slide-over Side Drawer showing Detailed Report */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
          {/* Backdrop blur */}
          <div
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity"
            onClick={() => setSelectedRecord(null)}
          />

          {/* Drawer content panel */}
          <div className="relative w-full max-w-xl bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto z-10 animate-slide-in p-6 space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-white ${selectedRecord.result.approved ? "bg-emerald-500" : "bg-rose-500"}`}>
                  {selectedRecord.result.approved ? "A" : "R"}
                </div>
                <div>
                  <h3 className="text-sm font-display font-bold text-slate-950">Detailed Audit Report</h3>
                  <p className="text-[10px] text-slate-500 font-mono">File ID: {selectedRecord.id}</p>
                </div>
              </div>

              <button
                id="btn-close-drawer"
                onClick={() => setSelectedRecord(null)}
                className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer"
              >
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {/* Core Applicant & Financial metrics */}
            <div className="space-y-4 text-xs font-light">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <div className="text-[10px] font-mono uppercase font-bold text-slate-400 mb-2">Demographic Profile</div>
                  <div className="space-y-1.5 text-slate-700">
                    <div><span className="font-semibold">Name:</span> {selectedRecord.applicantName}</div>
                    <div><span className="font-semibold">Email:</span> {selectedRecord.input.email}</div>
                    <div><span className="font-semibold">Age/Gender:</span> {selectedRecord.input.age} yrs / {selectedRecord.input.gender}</div>
                    <div><span className="font-semibold">Education:</span> {selectedRecord.input.education}</div>
                    <div><span className="font-semibold">Marital Status:</span> {selectedRecord.input.maritalStatus}</div>
                    <div><span className="font-semibold">Dependents:</span> {selectedRecord.input.numDependents}</div>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <div className="text-[10px] font-mono uppercase font-bold text-slate-400 mb-2">Solvency & Employment</div>
                  <div className="space-y-1.5 text-slate-700">
                    <div><span className="font-semibold">Occupation:</span> {selectedRecord.input.occupation}</div>
                    <div><span className="font-semibold">Employment:</span> {selectedRecord.input.employmentStatus}</div>
                    <div><span className="font-semibold">Duration:</span> {selectedRecord.input.yearsOfEmployment} Years</div>
                    <div><span className="font-semibold">Annual Income:</span> ${selectedRecord.input.annualIncome.toLocaleString()}</div>
                    <div><span className="font-semibold">Liquid Balance:</span> ${selectedRecord.input.bankBalance.toLocaleString()}</div>
                    <div><span className="font-semibold">Home Status:</span> {selectedRecord.input.propertyOwnership}</div>
                  </div>
                </div>
              </div>

              {/* Credit variables card */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-1.5 text-slate-700">
                <div className="text-[10px] font-mono uppercase font-bold text-slate-400 mb-2">Credit Risk Variables</div>
                <div className="grid grid-cols-2 gap-2">
                  <div><span className="font-semibold">FICO Score:</span> {selectedRecord.input.creditScore} Points</div>
                  <div><span className="font-semibold">Existing Loans:</span> {selectedRecord.input.existingLoans}</div>
                  <div><span className="font-semibold">Requested Loan:</span> ${selectedRecord.input.loanAmount.toLocaleString()}</div>
                  <div><span className="font-semibold">Monthly EMI:</span> ${selectedRecord.input.monthlyEMI.toLocaleString()}</div>
                </div>
              </div>

              {/* Narratives block */}
              <div className="space-y-2">
                <div className="text-[10px] font-mono uppercase font-bold text-slate-400">Gemini Underwriting Audit Summary</div>
                <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 leading-relaxed font-light whitespace-pre-line">
                  {selectedRecord.result.aiExplanation}
                </p>
              </div>

              <div className="space-y-2">
                <div className="text-[10px] font-mono uppercase font-bold text-slate-400">Roadmap Improvement Checklist</div>
                <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 leading-relaxed font-light whitespace-pre-line">
                  {selectedRecord.result.recommendation}
                </p>
              </div>
            </div>

            {/* Print and Actions Footer */}
            <div className="border-t border-slate-100 pt-4 flex justify-end gap-2 shrink-0">
              <button
                id="btn-drawer-print"
                onClick={() => handlePrintPDF(selectedRecord)}
                className="px-4 py-2.5 bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
              >
                Trigger Print Audit <Printer className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
