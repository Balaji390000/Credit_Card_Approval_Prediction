/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { User as UserType } from "../types";
import { apiFetch } from "../lib/api";
import { Shield, Key, AlertTriangle, CheckCircle, AlertCircle, Save } from "lucide-react";

interface ProfileViewProps {
  user: UserType;
  onProfileUpdate: (updatedUser: UserType) => void;
  onLogout: () => void;
}

export default function ProfileView({ user, onProfileUpdate, onLogout }: ProfileViewProps) {
  // Profile update state
  const [name, setName] = useState(user.name);
  const [profileSuccess, setProfileSuccess] = useState("");
  const [profileError, setProfileError] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);

  // Password update state
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [pwSuccess, setPwSuccess] = useState("");
  const [pwError, setPwError] = useState("");
  const [savingPw, setSavingPw] = useState(false);

  // Profile deletion state
  const [deleting, setDeleting] = useState(false);

  // Handle Profile Update
  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSuccess("");
    setProfileError("");

    if (!name.trim()) {
      setProfileError("Full name cannot be empty.");
      return;
    }

    setSavingProfile(true);
    try {
      const response = await apiFetch("/api/auth/update", {
        method: "PUT",
        body: JSON.stringify({ name }),
      });
      setProfileSuccess("Demographics updated successfully.");
      onProfileUpdate(response.user);
    } catch (err: any) {
      setProfileError(err.message || "Failed to update profile.");
    } finally {
      setSavingProfile(false);
    }
  };

  // Handle Password Change
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwSuccess("");
    setPwError("");

    if (!oldPassword || !newPassword || !confirmPassword) {
      setPwError("Please complete all password fields.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwError("The new password and confirm confirmation password do not match.");
      return;
    }
    if (newPassword.length < 6) {
      setPwError("New password must contain at least 6 characters.");
      return;
    }

    setSavingPw(true);
    try {
      await apiFetch("/api/auth/change-password", {
        method: "PUT",
        body: JSON.stringify({ oldPassword, newPassword }),
      });
      setPwSuccess("Password changed successfully.");
      setOldPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err: any) {
      setPwError(err.message || "Failed to change password.");
    } finally {
      setSavingPw(false);
    }
  };

  // Handle Account Deletion
  const handleDeleteAccount = async () => {
    if (user.role === "admin") {
      alert("Self-deletion safety: Admin accounts are protected and cannot be deleted via the profile screen. Contact security.");
      return;
    }

    if (!window.confirm("CRITICAL WARNING: This will permanently delete your user account, profile credentials, and all historical credit underwriting records in your session. This action cannot be undone. Do you wish to proceed?")) {
      return;
    }

    setDeleting(true);
    try {
      await apiFetch("/api/auth/delete", { method: "DELETE" });
      alert("Your account and all accompanying historical prediction files have been permanently purged.");
      onLogout();
    } catch (err: any) {
      alert(err.message || "Failed to close account");
      setDeleting(false);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-xl font-display font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <Shield className="w-5 h-5 text-sky-500" /> My Profile & Security Controls
        </h1>
        <p className="text-xs text-slate-500 font-light mt-1">
          Adjust demographic identifiers, rotating secret passwords, or request account closures.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Profile Details */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
            <Save className="w-4 h-4 text-sky-500" /> Demographics Settings
          </h3>

          <form onSubmit={handleProfileSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Email Address (Read-only)</label>
              <input
                id="input-profile-email"
                type="email"
                disabled
                value={user.email}
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-400 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Full Name</label>
              <input
                id="input-profile-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Assigned Role</label>
              <span className="inline-flex px-3 py-1 bg-slate-100 text-slate-700 text-[10px] uppercase font-mono font-bold rounded-lg border border-slate-200">
                {user.role} Mapping
              </span>
            </div>

            {profileSuccess && (
              <div className="p-3.5 bg-emerald-50 text-emerald-700 text-[11px] rounded-xl font-medium border border-emerald-100 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>{profileSuccess}</span>
              </div>
            )}

            {profileError && (
              <div className="p-3.5 bg-rose-50 text-rose-700 text-[11px] rounded-xl font-medium border border-rose-100 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-500" />
                <span>{profileError}</span>
              </div>
            )}

            <button
              id="btn-profile-submit"
              type="submit"
              disabled={savingProfile}
              className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white font-medium text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              {savingProfile ? "Saving Details..." : "Save Demographics"}
            </button>
          </form>
        </div>

        {/* Card 2: Security Credentials rotation */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
            <Key className="w-4 h-4 text-sky-500" /> Credentials Rotation
          </h3>

          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Current Password</label>
              <input
                id="input-pw-old"
                type="password"
                required
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">New Password</label>
              <input
                id="input-pw-new"
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Confirm New Password</label>
              <input
                id="input-pw-confirm"
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
              />
            </div>

            {pwSuccess && (
              <div className="p-3.5 bg-emerald-50 text-emerald-700 text-[11px] rounded-xl font-medium border border-emerald-100 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>{pwSuccess}</span>
              </div>
            )}

            {pwError && (
              <div className="p-3.5 bg-rose-50 text-rose-700 text-[11px] rounded-xl font-medium border border-rose-100 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-500" />
                <span>{pwError}</span>
              </div>
            )}

            <button
              id="btn-pw-submit"
              type="submit"
              disabled={savingPw}
              className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white font-medium text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Key className="w-4 h-4" />
              {savingPw ? "Rotating keys..." : "Rotate Credentials"}
            </button>
          </form>
        </div>
      </div>

      {/* Account Deletion Area */}
      {user.role !== "admin" && (
        <div className="bg-rose-50 border border-rose-100 p-6 rounded-2xl space-y-4">
          <div className="flex items-center gap-2 text-rose-800 font-display font-semibold">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>Danger Zone - Permanent Account Deletion</span>
          </div>
          
          <p className="text-xs text-rose-600 font-light leading-relaxed">
            By clicking the delete account button below, you will permanently purge your user profile database credentials and completely delete all credit underwriting logs. This action is irreversible.
          </p>

          <button
            id="btn-delete-profile-account"
            onClick={handleDeleteAccount}
            disabled={deleting}
            className="px-4 py-2 bg-rose-600 text-white hover:bg-rose-700 disabled:bg-slate-400 text-xs font-bold rounded-xl transition-all cursor-pointer inline-flex items-center gap-1.5"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            {deleting ? "Purging Files..." : "Purge Account & Prediction Data"}
          </button>
        </div>
      )}
    </div>
  );
}
