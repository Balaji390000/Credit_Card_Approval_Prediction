/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Shield, ArrowRight, RefreshCw, AlertCircle, Sparkles, User, DollarSign, Briefcase, FileText } from "lucide-react";
import { apiFetch } from "../lib/api";
import { PredictionInput, PredictionRecord } from "../types";

interface PredictionFormViewProps {
  onPredictionSuccess: (record: PredictionRecord) => void;
}

export default function PredictionFormView({ onPredictionSuccess }: PredictionFormViewProps) {
  const [formData, setFormData] = useState<PredictionInput>({
    fullName: "",
    email: "",
    gender: "Male",
    age: 35,
    maritalStatus: "Single",
    education: "Bachelor",
    employmentStatus: "Employed",
    occupation: "",
    yearsOfEmployment: 5,
    annualIncome: 65000,
    creditScore: 680,
    existingLoans: "none",
    loanAmount: 25000,
    monthlyEMI: 350,
    propertyOwnership: "rent",
    numDependents: 0,
    bankBalance: 12000,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");

  // Quick preset loader to assist testing!
  const loadPreset = (type: "prime" | "subprime") => {
    if (type === "prime") {
      setFormData({
        fullName: "Audrey Hepburn",
        email: "audrey.h@luxury.com",
        gender: "Female",
        age: 29,
        maritalStatus: "Married",
        education: "Master",
        employmentStatus: "Employed",
        occupation: "Data Architect",
        yearsOfEmployment: 6,
        annualIncome: 125000,
        creditScore: 785,
        existingLoans: "none",
        loanAmount: 45000,
        monthlyEMI: 400,
        propertyOwnership: "mortgage",
        numDependents: 1,
        bankBalance: 48000,
      });
    } else {
      setFormData({
        fullName: "Billy Kid",
        email: "billy.kid@outlaw.com",
        gender: "Male",
        age: 22,
        maritalStatus: "Single",
        education: "High School",
        employmentStatus: "Unemployed",
        occupation: "Temp Worker",
        yearsOfEmployment: 0,
        annualIncome: 18000,
        creditScore: 540,
        existingLoans: "multiple",
        loanAmount: 15000,
        monthlyEMI: 450,
        propertyOwnership: "rent",
        numDependents: 2,
        bankBalance: 350,
      });
    }
    setErrors({});
    setServerError("");
  };

  const validate = (): boolean => {
    const tempErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) tempErrors.fullName = "Full name is required";
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) tempErrors.email = "Email is required";
    else if (!emailRegex.test(formData.email)) tempErrors.email = "Invalid email format";

    if (!formData.occupation.trim()) tempErrors.occupation = "Occupation is required";

    if (formData.age < 18 || formData.age > 100) tempErrors.age = "Age must be between 18 and 100";
    if (formData.yearsOfEmployment < 0 || formData.yearsOfEmployment > 60) {
      tempErrors.yearsOfEmployment = "Years of employment must be between 0 and 60";
    }

    if (formData.annualIncome <= 0) tempErrors.annualIncome = "Income must be greater than zero";
    if (formData.creditScore < 300 || formData.creditScore > 850) {
      tempErrors.creditScore = "Credit score must be between 300 and 850";
    }
    if (formData.loanAmount <= 0) tempErrors.loanAmount = "Loan amount must be greater than zero";
    if (formData.monthlyEMI < 0) tempErrors.monthlyEMI = "Monthly EMI cannot be negative";
    if (formData.bankBalance < 0) tempErrors.bankBalance = "Bank balance cannot be negative";
    if (formData.numDependents < 0 || formData.numDependents > 15) {
      tempErrors.numDependents = "Dependents must be between 0 and 15";
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerError("");

    if (!validate()) return;

    setSubmitting(true);
    try {
      const response = await apiFetch<PredictionRecord>("/api/prediction/predict", {
        method: "POST",
        body: JSON.stringify(formData),
      });
      onPredictionSuccess(response);
    } catch (err: any) {
      setServerError(err.message || "Failed to complete predictive underwriting. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Header section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-xl font-display font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Shield className="w-5 h-5 text-sky-500" /> Underwriting Evaluation File
          </h1>
          <p className="text-xs text-slate-500 font-light mt-1">
            Perform an instantaneous machine learning risk analysis for standard line cards.
          </p>
        </div>

        {/* Quick Presets Buttons */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => loadPreset("prime")}
            className="px-3 py-1.5 bg-sky-50 text-sky-700 text-[10px] font-mono font-semibold rounded-lg hover:bg-sky-100 transition-all border border-sky-100 cursor-pointer"
          >
            + Load Low-Risk Preset
          </button>
          <button
            type="button"
            onClick={() => loadPreset("subprime")}
            className="px-3 py-1.5 bg-rose-50 text-rose-700 text-[10px] font-mono font-semibold rounded-lg hover:bg-rose-100 transition-all border border-rose-100 cursor-pointer"
          >
            + Load High-Risk Preset
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Box 1: Personal Demographic profile */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
            <h3 className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
              <User className="w-4 h-4 text-sky-500" /> Section A: Personal Profile
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Applicant Full Name</label>
                <input
                  id="input-fullName"
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                  placeholder="John Doe"
                />
                {errors.fullName && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.fullName}</p>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Email Address</label>
                  <input
                    id="input-email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                    placeholder="johndoe@email.com"
                  />
                  {errors.email && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.email}</p>}
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Gender</label>
                  <select
                    id="select-gender"
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 bg-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Age (Years)</label>
                  <input
                    id="input-age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                  />
                  {errors.age && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.age}</p>}
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Marital Status</label>
                  <select
                    id="select-maritalStatus"
                    value={formData.maritalStatus}
                    onChange={(e) => setFormData({ ...formData, maritalStatus: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  >
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Dependents</label>
                  <input
                    id="input-numDependents"
                    type="number"
                    value={formData.numDependents}
                    onChange={(e) => setFormData({ ...formData, numDependents: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  {errors.numDependents && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.numDependents}</p>}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Highest Education Tier</label>
                <select
                  id="select-education"
                  value={formData.education}
                  onChange={(e) => setFormData({ ...formData, education: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                >
                  <option value="High School">High School / Secondary</option>
                  <option value="Associate">Associate Degree</option>
                  <option value="Bachelor">Bachelor's Degree</option>
                  <option value="Master">Master's Degree</option>
                  <option value="PhD">PhD / Doctorate</option>
                </select>
              </div>
            </div>
          </div>

          {/* Box 2: Employment details */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
            <h3 className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
              <Briefcase className="w-4 h-4 text-sky-500" /> Section B: Professional Background
            </h3>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Employment Status</label>
                  <select
                    id="select-employmentStatus"
                    value={formData.employmentStatus}
                    onChange={(e) => setFormData({ ...formData, employmentStatus: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  >
                    <option value="Employed">Employed (Salaried)</option>
                    <option value="Self-Employed">Self-Employed / Business</option>
                    <option value="Retired">Retired / Pensioner</option>
                    <option value="Student">Student (Full-time)</option>
                    <option value="Unemployed">Unemployed / No Active Income</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Duration (Years)</label>
                  <input
                    id="input-yearsOfEmployment"
                    type="number"
                    value={formData.yearsOfEmployment}
                    onChange={(e) => setFormData({ ...formData, yearsOfEmployment: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  {errors.yearsOfEmployment && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.yearsOfEmployment}</p>}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Occupation Title</label>
                <input
                  id="input-occupation"
                  type="text"
                  value={formData.occupation}
                  onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  placeholder="e.g. Software Architect"
                />
                {errors.occupation && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.occupation}</p>}
              </div>

              <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-2 mt-4 text-[11px] text-slate-500 leading-normal font-light">
                <div className="font-semibold text-slate-800 flex items-center gap-1 font-sans">
                  <Sparkles className="w-3.5 h-3.5 text-sky-500" /> ML preprocessor conversion
                </div>
                The employment state is automatically preprocessed into structured label layers:
                Unemployed (0) &rarr; Student (1) &rarr; Retired (2) &rarr; Self-Employed (3) &rarr; Employed (4).
              </div>
            </div>
          </div>

          {/* Box 3: Financial Balances */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
            <h3 className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
              <DollarSign className="w-4 h-4 text-sky-500" /> Section C: Balance Sheet Solvency
            </h3>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Verifiable Annual Income ($)</label>
                  <input
                    id="input-annualIncome"
                    type="number"
                    value={formData.annualIncome}
                    onChange={(e) => setFormData({ ...formData, annualIncome: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  {errors.annualIncome && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.annualIncome}</p>}
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Liquid Bank Balance ($)</label>
                  <input
                    id="input-bankBalance"
                    type="number"
                    value={formData.bankBalance}
                    onChange={(e) => setFormData({ ...formData, bankBalance: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  {errors.bankBalance && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.bankBalance}</p>}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Home Ownership Status</label>
                <select
                  id="select-propertyOwnership"
                  value={formData.propertyOwnership}
                  onChange={(e) => setFormData({ ...formData, propertyOwnership: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                >
                  <option value="rent">Rent (Tenant)</option>
                  <option value="mortgage">Mortgage (Lien)</option>
                  <option value="own">Own (Outright Property)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Box 4: Credit Metrics */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
            <h3 className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
              <FileText className="w-4 h-4 text-sky-500" /> Section D: Credit Exposure
            </h3>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Credit Score (300-850 FICO)</label>
                  <input
                    id="input-creditScore"
                    type="number"
                    value={formData.creditScore}
                    onChange={(e) => setFormData({ ...formData, creditScore: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  {errors.creditScore && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.creditScore}</p>}
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Existing Active Loans</label>
                  <select
                    id="select-existingLoans"
                    value={formData.existingLoans}
                    onChange={(e) => setFormData({ ...formData, existingLoans: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  >
                    <option value="none">No Existing Debts</option>
                    <option value="one">Single Loan Active</option>
                    <option value="multiple">Multiple Active Loans</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Requested Loan Amount ($)</label>
                  <input
                    id="input-loanAmount"
                    type="number"
                    value={formData.loanAmount}
                    onChange={(e) => setFormData({ ...formData, loanAmount: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  {errors.loanAmount && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.loanAmount}</p>}
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Current Monthly EMI Outlay ($)</label>
                  <input
                    id="input-monthlyEMI"
                    type="number"
                    value={formData.monthlyEMI}
                    onChange={(e) => setFormData({ ...formData, monthlyEMI: parseInt(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500"
                  />
                  {errors.monthlyEMI && <p className="text-[10px] text-rose-500 font-medium mt-1">{errors.monthlyEMI}</p>}
                </div>
              </div>
            </div>
          </div>
        </div>

        {serverError && (
          <div className="p-4 bg-rose-50 text-rose-700 text-xs rounded-2xl border border-rose-100 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
            <span className="font-light">{serverError}</span>
          </div>
        )}

        {/* Action Button */}
        <div className="flex justify-end pt-4">
          <button
            id="btn-submit-underwriting"
            type="submit"
            disabled={submitting}
            className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white font-medium text-xs rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
          >
            {submitting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Running Underwriting Ensembles & Gemini Cognitive Explainer...</span>
              </>
            ) : (
              <>
                <span>Underwrite credit application file</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
