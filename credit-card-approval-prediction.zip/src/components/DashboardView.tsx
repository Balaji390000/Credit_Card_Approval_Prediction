/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  TrendingUp,
  ShieldAlert,
  UserCheck,
  Percent,
  PlusCircle,
  BarChart3,
  ExternalLink,
  Cpu,
  Clock,
  ArrowUpRight,
  UserX,
  AlertCircle
} from "lucide-react";
import { apiFetch } from "../lib/api";
import { User, PredictionRecord } from "../types";

interface DashboardViewProps {
  user: User;
  onTabChange: (tab: string) => void;
  onSelectReport: (record: PredictionRecord) => void;
}

export default function DashboardView({ user, onTabChange, onSelectReport }: DashboardViewProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [stats, setStats] = useState<any>(null);
  const [recentRecords, setRecentRecords] = useState<PredictionRecord[]>([]);

  const isAdmin = user.role === "admin";

  useEffect(() => {
    async function loadDashboardData() {
      setLoading(true);
      setError("");
      try {
        // Load summary metrics & comparison
        const data = await apiFetch("/api/analytics/dashboard");
        setStats(data);

        // Load prediction records for recent list
        const historyData = await apiFetch("/api/prediction/history?limit=5");
        setRecentRecords(historyData.records || []);
      } catch (err: any) {
        setError(err.message || "Failed to load dashboard parameters");
      } finally {
        setLoading(false);
      }
    }

    loadDashboardData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center min-h-[400px]">
        <div className="w-12 h-12 border-4 border-sky-200 border-t-sky-500 rounded-full animate-spin mb-4" />
        <span className="text-sm font-medium text-slate-500 font-mono">Synchronizing risk parameters...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-rose-50 border border-rose-100 rounded-2xl m-6 text-rose-700 space-y-3">
        <div className="flex items-center gap-2 font-display font-semibold">
          <AlertCircle className="w-5 h-5 text-rose-500" />
          <span>Sync Failure</span>
        </div>
        <p className="text-sm font-light">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs hover:bg-rose-700 transition-all font-medium"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const { summary, mlMetadata } = stats;

  return (
    <div className="p-6 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-slate-900 tracking-tight">
            Underwriting Dashboard
          </h1>
          <p className="text-xs text-slate-500 font-light font-mono mt-1">
            Session: {user.name} | Role: {isAdmin ? "SYSTEM ADMINISTRATOR" : "CREDIT REVIEWER"}
          </p>
        </div>

        <button
          id="btn-dash-new-prediction"
          onClick={() => onTabChange("prediction")}
          className="px-4 py-2.5 bg-sky-500 hover:bg-sky-600 text-white text-xs font-medium rounded-xl transition-all shadow-lg shadow-sky-500/15 flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" /> Evaluate Applicant
        </button>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Applications */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider">Total Evaluated</span>
            <div className="text-2xl font-display font-bold text-slate-900">{summary.totalPredictions}</div>
            <span className="text-[10px] text-slate-400 font-light flex items-center gap-1">
              <Clock className="w-3 h-3" /> Historical database log
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center">
            <Cpu className="w-5 h-5" />
          </div>
        </div>

        {/* FICO Score average */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider">Avg Credit Score</span>
            <div className="text-2xl font-display font-bold text-slate-900">{summary.avgCreditScore}</div>
            <span className="text-[10px] text-slate-400 font-light">
              FICO Scale range: 300 - 850
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-sky-50/50 text-sky-500 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Total Approvals */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider">Approvals</span>
            <div className="text-2xl font-display font-bold text-emerald-600">
              {summary.approvals} <span className="text-xs text-slate-400 font-normal font-sans">({summary.totalPredictions > 0 ? Math.round(summary.approvals/summary.totalPredictions*100) : 0}%)</span>
            </div>
            <span className="text-[10px] text-slate-400 font-light flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5 text-emerald-500" /> Active portfolio cards
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        {/* Total Rejections */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider">Declines</span>
            <div className="text-2xl font-display font-bold text-rose-600">
              {summary.rejections} <span className="text-xs text-slate-400 font-normal font-sans">({summary.totalPredictions > 0 ? Math.round(summary.rejections/summary.totalPredictions*100) : 0}%)</span>
            </div>
            <span className="text-[10px] text-slate-400 font-light flex items-center gap-1">
              <UserX className="w-3.5 h-3.5 text-rose-500" /> Elevated risk classifications
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <UserX className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Info & System Status Board */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* System Model Status card */}
        <div className="lg:col-span-4 bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl" />
          <h2 className="text-base font-display font-bold flex items-center gap-2 text-white mb-6">
            <Cpu className="w-4 h-4 text-sky-400" /> ML Engine Parameters
          </h2>

          <div className="space-y-4 text-xs font-mono">
            <div className="flex justify-between border-b border-white/5 pb-2.5">
              <span className="text-slate-400">Active Model</span>
              <span className="text-sky-400 font-bold">{mlMetadata.activeModel}</span>
            </div>
            <div className="flex justify-between border-b border-white/5 pb-2.5">
              <span className="text-slate-400">Evaluation Logic</span>
              <span className="text-slate-200">5-Alg Benchmarking</span>
            </div>
            <div className="flex justify-between border-b border-white/5 pb-2.5">
              <span className="text-slate-400">Baseline Dataset Size</span>
              <span className="text-slate-200">{mlMetadata.datasetSize} Records</span>
            </div>
            <div className="flex justify-between border-b border-white/5 pb-2.5">
              <span className="text-slate-400">Last Model retrain</span>
              <span className="text-amber-400 font-semibold">{new Date(mlMetadata.trainedAt).toLocaleDateString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Active Model Accuracy</span>
              <span className="text-emerald-400 font-bold">
                {Math.round((mlMetadata.modelComparison[mlMetadata.activeModel]?.accuracy || 0.915) * 1000) / 10}%
              </span>
            </div>

            <div className="pt-2">
              <button
                id="btn-dash-go-analytics"
                onClick={() => onTabChange("analytics")}
                className="w-full py-2.5 bg-white/10 hover:bg-white/15 text-white text-xs font-semibold rounded-xl border border-white/5 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Model Benchmarks <BarChart3 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Action guidelines card */}
        <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <h2 className="text-base font-display font-bold text-slate-900 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-sky-500" /> Operational Compliance Guidelines
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-light text-slate-500 leading-relaxed">
            <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
              <div className="font-semibold text-slate-800 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Low-Risk Tier (Approval)
              </div>
              <p>Applicants possessing credit scores above 680 and debt-to-income limits below 30% are high probability fits. Offer standard credit limits matching 15% of annual verifiable income.</p>
            </div>

            <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
              <div className="font-semibold text-slate-800 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-500" /> Elevated Risk Tier (Declines)
              </div>
              <p>Applicants with active multiple loan obligations, thin saving reserves under $5,000, or thin employment duration are classified as High/Critical. Use Gemini roadmaps to supply negative decline guides.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Predictions Table */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-base font-display font-bold text-slate-900">
            Recent Applications Log
          </h2>
          <button
            id="btn-dash-view-all-history"
            onClick={() => onTabChange("history")}
            className="text-xs text-sky-500 hover:text-sky-600 hover:underline transition-all font-semibold flex items-center gap-1 cursor-pointer"
          >
            Full Log <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentRecords.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs font-light">
            No applicant records logged in this session yet. Click "Evaluate Applicant" to start!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-light">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 uppercase font-mono tracking-wider font-semibold">
                  <th className="py-3 px-4">Applicant Name</th>
                  <th className="py-3 px-4">FICO</th>
                  <th className="py-3 px-4">Income</th>
                  <th className="py-3 px-4">Decision</th>
                  <th className="py-3 px-4">Risk Level</th>
                  <th className="py-3 px-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-slate-700">
                {recentRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-slate-50/50 transition-all">
                    <td className="py-3 px-4 font-semibold text-slate-900">{record.applicantName}</td>
                    <td className="py-3 px-4 font-mono font-medium">{record.creditScore}</td>
                    <td className="py-3 px-4 font-mono">${record.income.toLocaleString()}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-full font-semibold text-[10px] ${
                          record.result.approved
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
                            : "bg-rose-50 text-rose-700 border border-rose-100"
                        }`}
                      >
                        {record.result.approved ? "APPROVED" : "REJECTED"}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-full font-semibold text-[10px] ${
                          record.result.riskLevel === "Low"
                            ? "bg-emerald-50 text-emerald-700"
                            : record.result.riskLevel === "Medium"
                            ? "bg-amber-50 text-amber-700"
                            : "bg-rose-50 text-rose-700"
                        }`}
                      >
                        {record.result.riskLevel}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        id={`btn-dash-view-record-${record.id}`}
                        onClick={() => onSelectReport(record)}
                        className="p-1 text-slate-400 hover:text-sky-500 hover:bg-sky-500/10 rounded-lg transition-all cursor-pointer inline-flex items-center gap-1"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
