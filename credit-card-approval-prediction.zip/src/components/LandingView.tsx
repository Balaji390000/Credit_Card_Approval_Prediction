/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Shield, Sparkles, Database, BarChart3, ChevronRight, CheckCircle, MessageSquare, ChevronDown, Send } from "lucide-react";
import { apiFetch } from "../lib/api";

interface LandingViewProps {
  onNavigateToLogin: () => void;
  onNavigateToRegister: () => void;
}

export default function LandingView({ onNavigateToLogin, onNavigateToRegister }: LandingViewProps) {
  // Mini predictor state for interactive hero card
  const [miniScore, setMiniScore] = useState(680);
  const [miniIncome, setMiniIncome] = useState(65000);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  
  // Contact Form State
  const [contactForm, setContactForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [contactSuccess, setContactSuccess] = useState("");
  const [contactError, setContactError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Quick calculator result
  const miniApproved = miniScore >= 660 && (miniIncome / 12) > 2500;
  const miniProbability = Math.round(
    Math.min(99, Math.max(5, ((miniScore - 300) / 550) * 70 + (miniIncome > 100000 ? 25 : miniIncome > 50000 ? 15 : 5)))
  );

  const faqs = [
    {
      q: "How does the AI credit card approval system work?",
      a: "Our system combines classical machine learning models (Logistic Regression, Decision Trees, Random Forests, SVM, and XGBoost) with Gemini AI. First, the mathematical ML engine analyzes historical risk patterns to estimate approval probability and risk level. Then, Gemini AI processes the quantitative outputs to produce a contextualized explanation and a personalized financial recommendation roadmap."
    },
    {
      q: "Which credit card prediction dataset is utilized?",
      a: "The underlying model is trained on the classic Credit Card Approval Dataset from the UCI Machine Learning Repository and Kaggle. It covers 17 demographic, financial, and credit history attributes, standardizing continuous values and encoding categorical attributes to mimic an institutional banking underwriting system."
    },
    {
      q: "What security features protect my sensitive financial data?",
      a: "We adhere to enterprise fintech security compliance. Passwords are salted and hashed using one-way cryptographic SHA-256 algorithms. All data validation happens server-side to prevent SQL injection and cross-site scripting (XSS) exploits. No credentials or keys are exposed to the client-side browser."
    },
    {
      q: "What is the Financial Health Score and Risk Level?",
      a: "The Financial Health Score (0-100) measures your overall balance sheet strength, combining credit scores (40%), debt-to-income ratio (30%), liquid bank savings (20%), and employment stability (10%). The Risk Level (Low, Medium, High, Critical) calculates default probability vectors, helping underwriters make objective lending limits."
    },
    {
      q: "How often are the ML models updated or retrained?",
      a: "Admins can monitor live prediction metrics and trigger a manual model retraining pipeline at any time. The retraining engine parses the entire dataset, splits samples into 75/25 train/test blocks, runs K-fold cross-validations, benchmarks the 5 distinct algorithms, and automatically promotes the highest-accuracy model to active production status."
    }
  ];

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.subject || !contactForm.message) {
      setContactError("Please fill out all contact fields.");
      return;
    }

    setSubmitting(true);
    setContactSuccess("");
    setContactError("");

    try {
      await apiFetch("/api/contact", {
        method: "POST",
        body: JSON.stringify(contactForm),
      });
      setContactSuccess("Your message has been logged in our system. An administrator will reply shortly.");
      setContactForm({ name: "", email: "", subject: "", message: "" });
    } catch (err: any) {
      setContactError(err.message || "Failed to submit message.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full bg-slate-50 min-h-screen text-slate-800">
      {/* Hero Section */}
      <section id="landing-hero" className="relative overflow-hidden pt-20 pb-24 md:pt-28 md:pb-36 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white">
        {/* Subtle decorative grid/glows */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem]" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-sky-500/10 blur-[100px] rounded-full" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.py-1 py-1 px-3.5 rounded-full bg-sky-500/10 border border-sky-400/20 text-sky-400 text-xs font-medium uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" /> Next-Gen Fintech Risk Assessment
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold tracking-tight leading-tight">
              AI-Powered <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-sky-300 to-blue-500">Credit Approval</span> & Risk Management
            </h1>
            
            <p className="text-slate-400 text-lg max-w-xl font-light leading-relaxed">
              An enterprise-grade, full-stack decision intelligence platform. Combine multi-model machine learning classifications with Gemini's underwriting reasoning to predict, analyze, and optimize credit approvals in milliseconds.
            </p>
            
            <div className="flex flex-wrap gap-4 pt-4">
              <button
                id="btn-hero-register"
                onClick={onNavigateToRegister}
                className="px-6 py-3.5 rounded-xl font-medium bg-sky-500 text-white hover:bg-sky-600 shadow-lg shadow-sky-500/25 transition-all flex items-center gap-2"
              >
                Get Started (Register) <ChevronRight className="w-4 h-4" />
              </button>
              <button
                id="btn-hero-login"
                onClick={onNavigateToLogin}
                className="px-6 py-3.5 rounded-xl font-medium bg-white/10 text-white hover:bg-white/15 border border-white/10 transition-all"
              >
                Access Dashboard
              </button>
            </div>
          </div>

          {/* Interactive Mini Predictor Card on Hero */}
          <div className="lg:col-span-5">
            <div className="dark-glass-panel rounded-2xl p-6 border border-white/10 shadow-2xl relative">
              <div className="absolute top-3 right-3 flex items-center gap-1 text-[10px] uppercase font-mono tracking-wider text-sky-400 bg-sky-400/10 px-2 py-0.5 rounded">
                ● Live Simulation
              </div>
              <h3 className="text-base font-display font-medium text-white mb-5 flex items-center gap-2">
                <Shield className="w-4 h-4 text-sky-400" /> Mini Underwriter Sandbox
              </h3>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1.5 font-mono">
                    <span>Credit Score</span>
                    <span className="text-sky-400 font-bold">{miniScore} FICO</span>
                  </div>
                  <input
                    id="slider-mini-score"
                    type="range"
                    min="300"
                    max="850"
                    value={miniScore}
                    onChange={(e) => setMiniScore(parseInt(e.target.value))}
                    className="w-full accent-sky-500 bg-slate-800 rounded-lg appearance-none h-2 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1.5 font-mono">
                    <span>Annual Income</span>
                    <span className="text-sky-400 font-bold">${miniIncome.toLocaleString()}</span>
                  </div>
                  <input
                    id="slider-mini-income"
                    type="range"
                    min="10000"
                    max="150000"
                    step="5000"
                    value={miniIncome}
                    onChange={(e) => setMiniIncome(parseInt(e.target.value))}
                    className="w-full accent-sky-500 bg-slate-800 rounded-lg appearance-none h-2 cursor-pointer"
                  />
                </div>

                <div className="border-t border-white/5 pt-4 mt-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-mono">Simulated Decision</div>
                      <div className={`text-xl font-display font-bold ${miniApproved ? "text-emerald-400" : "text-rose-400"}`}>
                        {miniApproved ? "CONDITIONAL APPROVAL" : "PROBABLE REJECTION"}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-slate-400 uppercase font-mono">Probability Score</div>
                      <div className="text-xl font-display font-semibold text-white">
                        {miniProbability}%
                      </div>
                    </div>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="w-full bg-slate-800 rounded-full h-2 mt-3 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        miniApproved ? "bg-emerald-400" : "bg-rose-400"
                      }`}
                      style={{ width: `${miniProbability}%` }}
                    />
                  </div>

                  <p className="text-[11px] text-slate-500 mt-3 text-center leading-normal">
                    This is a simplified regression model. Register to gain full access to multi-model ML benchmarking, advanced feature scaling, and detailed Gemini AI analysis.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Section */}
      <section id="landing-features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900">
              Complete Institutional Risk Architecture
            </h2>
            <p className="text-slate-500 font-light">
              We upgrade legacy scoring models with mathematical ensembles and cognitive AI explanations. Experience high-fidelity credit analytics.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="p-6 bg-slate-50 rounded-2xl hover:shadow-xl hover:shadow-slate-100 transition-all space-y-4 group border border-slate-100">
              <div className="w-12 h-12 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center group-hover:bg-sky-500 group-hover:text-white transition-all">
                <Database className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-display font-semibold text-slate-900">Advanced Pipeline</h3>
              <p className="text-sm text-slate-500 leading-relaxed font-light">
                Full-featured data preprocessor covering missing value imputations, label mappings, feature standardization, and 75/25 split.
              </p>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl hover:shadow-xl hover:shadow-slate-100 transition-all space-y-4 group border border-slate-100">
              <div className="w-12 h-12 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center group-hover:bg-sky-500 group-hover:text-white transition-all">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-display font-semibold text-slate-900">Multi-Model Benchmarks</h3>
              <p className="text-sm text-slate-500 leading-relaxed font-light">
                Mathematically trains and compares 5 core algorithms: Logistic Regression, Decision Tree, Random Forest, SVM, and XGBoost.
              </p>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl hover:shadow-xl hover:shadow-slate-100 transition-all space-y-4 group border border-slate-100">
              <div className="w-12 h-12 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center group-hover:bg-sky-500 group-hover:text-white transition-all">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-display font-semibold text-slate-900">Gemini Underwriting</h3>
              <p className="text-sm text-slate-500 leading-relaxed font-light">
                Generates natural language risk explanations and highly detailed, personalized financial roadmap lists for applicants.
              </p>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl hover:shadow-xl hover:shadow-slate-100 transition-all space-y-4 group border border-slate-100">
              <div className="w-12 h-12 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center group-hover:bg-sky-500 group-hover:text-white transition-all">
                <BarChart3 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-display font-semibold text-slate-900">Interactive Dashboards</h3>
              <p className="text-sm text-slate-500 leading-relaxed font-light">
                Stunning analytics for monthly predictions, risk spreads, score distributions, and interactive ROC Curve graphing.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="landing-about" className="py-20 bg-slate-50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6">
            <div className="text-xs uppercase tracking-wider text-sky-600 font-bold font-mono">THE PROBLEM & OBJECTIVE</div>
            <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 leading-tight">
              Demystifying Credit Risk Decisions through Hybrid AI
            </h2>
            <p className="text-slate-500 font-light leading-relaxed">
              In traditional banking systems, credit approval formulas are often closed black-boxes, yielding sterile scores without clear, human explanations. This leads to customer frustration and rigid risk profiling.
            </p>
            <p className="text-slate-500 font-light leading-relaxed">
              <strong>Our Objective:</strong> To build an enterprise underwriting sandbox that bridges the gap. By processing 17 key applicant attributes, we run mathematical classification benchmarks to guarantee prediction accuracy, and use Gemini Generative AI to compile clear explainability maps and positive improvement checklists.
            </p>
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span className="text-xs font-semibold text-slate-700">100% Client Data Control</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span className="text-xs font-semibold text-slate-700">Active Model Retraining</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span className="text-xs font-semibold text-slate-700">Audit Logs & Admin Station</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span className="text-xs font-semibold text-slate-700">PDF Report Generators</span>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-6">
            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-xl space-y-6">
              <h3 className="text-lg font-display font-bold text-slate-900 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-sky-500" /> System Model Comparison Performance
              </h3>
              
              <div className="space-y-4 text-xs font-mono">
                <div>
                  <div className="flex justify-between mb-1 text-slate-600 font-sans">
                    <span className="font-medium">1. XGBoost Classifier</span>
                    <span className="font-semibold text-sky-600">92.4% Accuracy (Recommended)</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-sky-400 to-sky-500 h-full rounded-full" style={{ width: "92.4%" }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 text-slate-600 font-sans">
                    <span className="font-medium">2. Random Forest</span>
                    <span className="font-semibold text-slate-700">91.8% Accuracy</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-slate-400 h-full rounded-full" style={{ width: "91.8%" }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 text-slate-600 font-sans">
                    <span className="font-medium">3. SVM (Linear Kernel)</span>
                    <span className="font-semibold text-slate-700">89.5% Accuracy</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-slate-400 h-full rounded-full" style={{ width: "89.5%" }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 text-slate-600 font-sans">
                    <span className="font-medium">4. Logistic Regression</span>
                    <span className="font-semibold text-slate-700">88.2% Accuracy</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-slate-300 h-full rounded-full" style={{ width: "88.2%" }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 text-slate-600 font-sans">
                    <span className="font-medium">5. Decision Tree</span>
                    <span className="font-semibold text-slate-700">86.1% Accuracy</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-slate-300 h-full rounded-full" style={{ width: "86.1%" }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="landing-faq" className="py-20 bg-white border-t border-slate-100">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl font-display font-bold text-slate-900">Frequently Asked Questions</h2>
            <p className="text-slate-500 font-light">Find instant answers regarding our underwriting engine, accuracy metrics, and security compliance.</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 transition-all"
              >
                <button
                  onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                  className="w-full flex items-center justify-between p-5 text-left font-sans font-semibold text-slate-800 hover:bg-slate-100/50 transition-all"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-all ${activeFaq === index ? "rotate-180" : ""}`} />
                </button>
                {activeFaq === index && (
                  <div className="px-5 pb-5 pt-1 text-sm text-slate-500 font-light leading-relaxed border-t border-slate-100">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="landing-contact" className="py-20 bg-slate-50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5 space-y-6">
            <div className="text-xs uppercase tracking-wider text-sky-600 font-bold font-mono">SUPPORT INBOX</div>
            <h2 className="text-3xl font-display font-bold text-slate-900 leading-tight">Connect With Our Credit Risk Officers</h2>
            <p className="text-slate-500 font-light leading-relaxed">
              Have specific questions about credit policies, custom dataset integrations, or commercial license pricing? Reach out using our general support contact form, and an engineer will reply within 24 business hours.
            </p>
            
            <div className="space-y-4 text-xs font-mono text-slate-600">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-sky-500" />
                <span>FINTECH SECURE ENVIRONMENT</span>
              </div>
              <div className="flex items-center gap-3">
                <MessageSquare className="w-5 h-5 text-sky-500" />
                <span>SUPPORT: admin@fintechbank.com</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
            <form onSubmit={handleContactSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Full Name</label>
                  <input
                    id="input-contact-name"
                    type="text"
                    required
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    placeholder="E.g., John Doe"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Email Address</label>
                  <input
                    id="input-contact-email"
                    type="email"
                    required
                    value={contactForm.email}
                    onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                    placeholder="your@email.com"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Subject</label>
                <input
                  id="input-contact-subject"
                  type="text"
                  required
                  value={contactForm.subject}
                  onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                  placeholder="E.g., Custom Dataset Integration"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Inquiry Details</label>
                <textarea
                  id="input-contact-message"
                  required
                  rows={4}
                  value={contactForm.message}
                  onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                  placeholder="Describe your inquiry..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                />
              </div>

              {contactSuccess && (
                <div className="p-4 bg-emerald-50 text-emerald-700 text-xs rounded-xl font-medium border border-emerald-100">
                  {contactSuccess}
                </div>
              )}

              {contactError && (
                <div className="p-4 bg-rose-50 text-rose-700 text-xs rounded-xl font-medium border border-rose-100">
                  {contactError}
                </div>
              )}

              <button
                id="btn-contact-submit"
                type="submit"
                disabled={submitting}
                className="w-full px-5 py-3 rounded-xl font-medium text-white bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 transition-all flex items-center justify-center gap-2"
              >
                {submitting ? "Sending Inquiry..." : "Submit Support Form"} <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Elegant Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 py-12 text-xs">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 text-white font-display font-bold text-sm">
            <Shield className="w-5 h-5 text-sky-400" /> Credit Card Approval Prediction System
          </div>
          <div className="flex gap-6 font-light">
            <a href="#landing-hero" className="hover:text-white transition-all">Home</a>
            <a href="#landing-features" className="hover:text-white transition-all">Features</a>
            <a href="#landing-about" className="hover:text-white transition-all">About</a>
            <a href="#landing-faq" className="hover:text-white transition-all">FAQ</a>
            <a href="#landing-contact" className="hover:text-white transition-all">Contact</a>
          </div>
          <div className="font-light">
            &copy; 2026 Fintech Bank Inc. All rights reserved. Built for security & clarity.
          </div>
        </div>
      </footer>
    </div>
  );
}
