/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Terminal,
  Users,
  MessageSquare,
  RefreshCw,
  Trash2,
  Cpu,
  AlertCircle,
  FileText,
  CheckCircle,
  ShieldAlert,
  Search,
  Filter,
  Check
} from "lucide-react";
import { apiFetch } from "../lib/api";
import { User, SystemLog, ContactMessage, RetrainingMetadata } from "../types";

interface AdminViewProps {
  currentUser: User;
}

export default function AdminView({ currentUser }: AdminViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<"retrain" | "users" | "logs" | "contacts">("retrain");

  // State management
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Data State
  const [users, setUsers] = useState<User[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [contacts, setContacts] = useState<ContactMessage[]>([]);
  const [mlMeta, setMlMeta] = useState<RetrainingMetadata | null>(null);

  // Search/Filters
  const [logSearch, setLogSearch] = useState("");
  const [logLevel, setLogLevel] = useState("all");

  const loadData = async () => {
    setLoading(true);
    setError("");
    try {
      if (activeSubTab === "retrain") {
        const dashboardData = await apiFetch("/api/analytics/dashboard");
        setMlMeta(dashboardData.mlMetadata);
      } else if (activeSubTab === "users") {
        const usersData = await apiFetch<User[]>("/api/admin/users");
        setUsers(usersData);
      } else if (activeSubTab === "logs") {
        const logsData = await apiFetch<SystemLog[]>("/api/admin/logs");
        setLogs(logsData);
      } else if (activeSubTab === "contacts") {
        const contactsData = await apiFetch<ContactMessage[]>("/api/admin/contacts");
        setContacts(contactsData);
      }
    } catch (err: any) {
      setError(err.message || "Failed to load administrative modules");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    setSuccess("");
  }, [activeSubTab]);

  // Handle retraining trigger
  const handleRetrain = async () => {
    if (!window.confirm("Trigger new model retraining? This will run standard K-fold cross-validations on all 5 algorithms and promote the highest F1-score candidate.")) {
      return;
    }

    setActionLoading(true);
    setSuccess("");
    setError("");
    try {
      const response = await apiFetch("/api/admin/retrain", { method: "POST" });
      setSuccess(`Model Retraining Pipeline complete! Selected: ${response.activeModel}. Training accuracy: ${Math.round(response.accuracy * 1000) / 10}%`);
      
      // Update local state
      const dashboardData = await apiFetch("/api/analytics/dashboard");
      setMlMeta(dashboardData.mlMetadata);
    } catch (err: any) {
      setError(err.message || "Retraining pipeline encountered a regression failure.");
    } finally {
      setActionLoading(false);
    }
  };

  // Handle User Deletion
  const handleDeleteUser = async (userId: string) => {
    if (userId === currentUser.id) {
      alert("Self-deletion protection: You cannot delete your own active admin account.");
      return;
    }
    if (!window.confirm("Are you sure you want to delete this user? All their credit records will be purged.")) {
      return;
    }

    try {
      await apiFetch(`/api/admin/users/${userId}`, { method: "DELETE" });
      setSuccess("User account deleted successfully.");
      setUsers(users.filter((u) => u.id !== userId));
    } catch (err: any) {
      setError(err.message || "Failed to delete user account");
    }
  };

  // Delete Support Inquiries
  const handleDeleteContact = async (id: string) => {
    if (!window.confirm("Delete support inquiry log?")) return;

    try {
      await apiFetch(`/api/admin/contacts/${id}`, { method: "DELETE" });
      setSuccess("Support inquiry record removed.");
      setContacts(contacts.filter((c) => c.id !== id));
    } catch (err: any) {
      setError(err.message || "Failed to delete contact record");
    }
  };

  // Filter logs locally
  const filteredLogs = logs.filter((log) => {
    const matchesSearch = log.message.toLowerCase().includes(logSearch.toLowerCase()) ||
                          (log.userEmail && log.userEmail.toLowerCase().includes(logSearch.toLowerCase()));
    const matchesLevel = logLevel === "all" || log.level.toLowerCase() === logLevel.toLowerCase();
    return matchesSearch && matchesLevel;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-xl font-display font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-amber-500" /> Admin Command Center
        </h1>
        <p className="text-xs text-slate-500 font-light mt-1">
          Perform training pipelines, monitor accounts, review system audit records, and resolve support tickets.
        </p>
      </div>

      {/* Admin tabs */}
      <div className="flex border-b border-slate-200 gap-1 overflow-x-auto text-xs font-medium">
        <button
          onClick={() => setActiveSubTab("retrain")}
          className={`px-4 py-2.5 transition-all border-b-2 cursor-pointer ${
            activeSubTab === "retrain"
              ? "border-amber-500 text-slate-900 font-bold"
              : "border-transparent text-slate-500 hover:text-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <Cpu className="w-4 h-4" /> Retraining Sandbox
          </div>
        </button>

        <button
          onClick={() => setActiveSubTab("users")}
          className={`px-4 py-2.5 transition-all border-b-2 cursor-pointer ${
            activeSubTab === "users"
              ? "border-amber-500 text-slate-900 font-bold"
              : "border-transparent text-slate-500 hover:text-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <Users className="w-4 h-4" /> User Base Manager
          </div>
        </button>

        <button
          onClick={() => setActiveSubTab("logs")}
          className={`px-4 py-2.5 transition-all border-b-2 cursor-pointer ${
            activeSubTab === "logs"
              ? "border-amber-500 text-slate-900 font-bold"
              : "border-transparent text-slate-500 hover:text-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <Terminal className="w-4 h-4" /> System Audit Logs
          </div>
        </button>

        <button
          onClick={() => setActiveSubTab("contacts")}
          className={`px-4 py-2.5 transition-all border-b-2 cursor-pointer ${
            activeSubTab === "contacts"
              ? "border-amber-500 text-slate-900 font-bold"
              : "border-transparent text-slate-500 hover:text-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <MessageSquare className="w-4 h-4" /> Customer Inquiries
          </div>
        </button>
      </div>

      {/* Alerts */}
      {success && (
        <div className="p-4 bg-emerald-50 text-emerald-800 text-xs rounded-xl font-medium border border-emerald-100 flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {error && (
        <div className="p-4 bg-rose-50 text-rose-800 text-xs rounded-xl font-medium border border-rose-100 flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Tab Panels */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-10 h-10 border-4 border-amber-100 border-t-amber-500 rounded-full animate-spin" />
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 overflow-hidden">
          {/* Sub Tab: ML Retraining pipeline */}
          {activeSubTab === "retrain" && mlMeta && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-50 pb-4">
                <div>
                  <h3 className="text-sm font-display font-bold text-slate-950">Mathematical Retraining Pipeline</h3>
                  <p className="text-[11px] text-slate-500 font-light">Trigger real-time retraining models and optimize active underwriting metrics.</p>
                </div>
                
                <button
                  id="btn-admin-trigger-retrain"
                  onClick={handleRetrain}
                  disabled={actionLoading}
                  className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-300 text-slate-950 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-amber-500/10 shrink-0"
                >
                  <RefreshCw className={`w-4 h-4 ${actionLoading ? "animate-spin" : ""}`} />
                  {actionLoading ? "Fitting models..." : "Retrain Engine"}
                </button>
              </div>

              {/* Training Progress display if loading */}
              {actionLoading && (
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-center space-y-4">
                  <div className="w-12 h-12 border-4 border-amber-100 border-t-amber-500 rounded-full animate-spin mx-auto" />
                  <div className="text-xs font-mono text-slate-600 max-w-md mx-auto space-y-2">
                    <p className="font-semibold text-slate-800">Pipeline Executing:</p>
                    <div className="grid grid-cols-5 gap-1.5 text-[9px] uppercase font-bold text-slate-400">
                      <div className="bg-amber-500/10 text-amber-600 p-1 rounded animate-pulse">Standardizing</div>
                      <div className="bg-amber-500/10 text-amber-600 p-1 rounded animate-pulse">LogReg</div>
                      <div className="bg-amber-500/10 text-amber-600 p-1 rounded animate-pulse">SVM</div>
                      <div className="bg-amber-500/10 text-amber-600 p-1 rounded animate-pulse">RandomFor</div>
                      <div className="bg-amber-500/10 text-amber-600 p-1 rounded animate-pulse">XGBoost</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Metadata Benchmarks info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">Active Algorithm</span>
                  <div className="text-lg font-display font-semibold text-slate-900">{mlMeta.activeModel}</div>
                  <p className="text-[10px] text-slate-400">Selected automatically based on F1 classification score.</p>
                </div>
                
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">Historical Base Size</span>
                  <div className="text-lg font-display font-semibold text-slate-900">{mlMeta.datasetSize} Rows</div>
                  <p className="text-[10px] text-slate-400">Active rows mapped during feature mapping split.</p>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">Last Fit Stamp</span>
                  <div className="text-lg font-display font-semibold text-slate-900">{new Date(mlMeta.trainedAt).toLocaleDateString()}</div>
                  <p className="text-[10px] text-slate-400">Retrain trigger stamp on database sync.</p>
                </div>
              </div>

              {/* Models performance list */}
              <div className="space-y-3">
                <h4 className="text-xs uppercase font-mono font-bold text-slate-400">Current Model Performance Ledger</h4>
                <div className="overflow-x-auto border border-slate-100 rounded-xl">
                  <table className="w-full text-left text-xs font-light">
                    <thead>
                      <tr className="bg-slate-50 font-mono text-slate-400 uppercase font-bold">
                        <th className="py-2.5 px-4">Algorithm Name</th>
                        <th className="py-2.5 px-4">Accuracy</th>
                        <th className="py-2.5 px-4">Precision</th>
                        <th className="py-2.5 px-4">Recall</th>
                        <th className="py-2.5 px-4">F1 Score</th>
                        <th className="py-2.5 px-4 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50 text-slate-700">
                      {Object.keys(mlMeta.modelComparison).map((name) => {
                        const isChosen = name === mlMeta.activeModel;
                        const met = mlMeta.modelComparison[name];
                        return (
                          <tr key={name} className={isChosen ? "bg-amber-500/5 font-semibold text-slate-950" : ""}>
                            <td className="py-3 px-4 font-medium">{name}</td>
                            <td className="py-3 px-4 font-mono">{Math.round(met.accuracy * 1000) / 10}%</td>
                            <td className="py-3 px-4 font-mono">{Math.round(met.precision * 1000) / 10}%</td>
                            <td className="py-3 px-4 font-mono">{Math.round(met.recall * 1000) / 10}%</td>
                            <td className="py-3 px-4 font-mono">{Math.round(met.f1Score * 1000) / 10}%</td>
                            <td className="py-3 px-4 text-right">
                              {isChosen ? (
                                <span className="inline-flex px-2 py-0.5 bg-amber-500 text-slate-950 font-bold text-[9px] font-mono rounded">
                                  ACTIVE
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400">Idle</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Sub Tab: User Control */}
          {activeSubTab === "users" && (
            <div className="space-y-4">
              <h3 className="text-sm font-display font-bold text-slate-950">Active Users Base</h3>
              <div className="overflow-x-auto border border-slate-100 rounded-xl">
                <table className="w-full text-left text-xs font-light">
                  <thead>
                    <tr className="bg-slate-50 text-slate-400 font-mono uppercase font-bold">
                      <th className="py-3 px-4">Name</th>
                      <th className="py-3 px-4">Email Address</th>
                      <th className="py-3 px-4">Role Mapping</th>
                      <th className="py-3 px-4">Created Date</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 text-slate-700">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/50 transition-all">
                        <td className="py-3 px-4 font-semibold text-slate-900">{u.name}</td>
                        <td className="py-3 px-4 text-slate-500 font-mono">{u.email}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`inline-flex px-2 py-0.5 rounded font-mono text-[10px] uppercase font-bold ${
                              u.role === "admin" ? "bg-amber-100 text-amber-800" : "bg-sky-50 text-sky-800"
                            }`}
                          >
                            {u.role}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-light text-slate-400">
                          {new Date(u.createdAt || Date.now()).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            id={`btn-admin-delete-user-${u.id}`}
                            onClick={() => handleDeleteUser(u.id)}
                            disabled={u.id === currentUser.id}
                            className="p-1.5 text-slate-400 hover:text-rose-500 disabled:opacity-40 rounded-lg transition-all cursor-pointer"
                            title="Delete User Purge"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Sub Tab: Audit Logs */}
          {activeSubTab === "logs" && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h3 className="text-sm font-display font-bold text-slate-950">Real-Time System Audit Trail</h3>
                
                {/* Search / Filters for logs */}
                <div className="flex gap-2 w-full sm:w-auto text-xs">
                  <div className="relative flex-1 sm:flex-initial">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                    <input
                      id="input-log-search"
                      type="text"
                      value={logSearch}
                      onChange={(e) => setLogSearch(e.target.value)}
                      placeholder="Filter message or email..."
                      className="pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <select
                    id="select-log-level"
                    value={logLevel}
                    onChange={(e) => setLogLevel(e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white"
                  >
                    <option value="all">All Levels</option>
                    <option value="info">INFO</option>
                    <option value="warn">WARN</option>
                    <option value="error">ERROR</option>
                  </select>
                </div>
              </div>

              {/* Log Console window */}
              <div className="bg-slate-950 text-emerald-400 p-4 rounded-xl border border-slate-900 h-[380px] overflow-y-auto font-mono text-[11px] leading-relaxed space-y-2.5">
                {filteredLogs.length === 0 ? (
                  <div className="text-slate-500 text-center py-12">
                    No matching audit lines in this log buffer segment.
                  </div>
                ) : (
                  filteredLogs.map((log) => {
                    const time = new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    const isErr = log.level === "ERROR";
                    const isWarn = log.level === "WARN";
                    const color = isErr ? "text-rose-500" : isWarn ? "text-amber-400" : "text-emerald-400";
                    return (
                      <div key={log.id} className="hover:bg-slate-900 p-1 rounded transition-all">
                        <span className="text-slate-500 font-light mr-2">[{time}]</span>
                        <span className={`${color} font-bold mr-2 uppercase`}>[{log.level}]</span>
                        {log.userEmail && <span className="text-indigo-400 font-semibold mr-1">({log.userEmail})</span>}
                        <span className="text-slate-300 font-light">{log.message}</span>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* Sub Tab: Customer Inquiries */}
          {activeSubTab === "contacts" && (
            <div className="space-y-4">
              <h3 className="text-sm font-display font-bold text-slate-950">Customer Inquiries Inbox</h3>
              
              {contacts.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs font-light">
                  All customer support tickets are currently resolved and empty!
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {contacts.map((c) => (
                    <div key={c.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50 space-y-3 relative group">
                      <button
                        id={`btn-delete-contact-${c.id}`}
                        onClick={() => handleDeleteContact(c.id)}
                        className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                        title="Delete Support log"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="text-xs font-semibold text-slate-900 font-sans">{c.subject}</h4>
                          <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">
                            Sender: {c.name} ({c.email}) | Sent: {new Date(c.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 font-light leading-relaxed whitespace-pre-line bg-white p-3 rounded-lg border border-slate-100">
                        {c.message}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
