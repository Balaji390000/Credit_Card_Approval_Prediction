/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import {
  LayoutDashboard,
  PlusCircle,
  History,
  BarChart3,
  User,
  Settings,
  ShieldAlert,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Shield,
  HelpCircle,
  Terminal
} from "lucide-react";
import { User as UserType } from "../types";

interface SidebarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  user: UserType;
  onLogout: () => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export default function Sidebar({
  currentTab,
  onTabChange,
  user,
  onLogout,
  collapsed,
  setCollapsed,
}: SidebarProps) {
  const isAdmin = user.role === "admin";

  const mainNavItems = [
    { id: "dashboard", label: "Overview", icon: LayoutDashboard },
    { id: "prediction", label: "New Prediction", icon: PlusCircle },
    { id: "history", label: "History Log", icon: History },
    { id: "analytics", label: "Analytics Hub", icon: BarChart3 },
    { id: "profile", label: "My Profile", icon: User },
  ];

  const adminNavItems = [
    { id: "admin-models", label: "Model Optimization", icon: Terminal },
    { id: "admin-users", label: "User Control", icon: ShieldAlert },
  ];

  return (
    <div
      className={`h-screen bg-slate-900 border-r border-slate-800 text-slate-300 flex flex-col justify-between transition-all duration-300 relative ${
        collapsed ? "w-20" : "w-64"
      }`}
    >
      {/* Sidebar header */}
      <div>
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center shrink-0 border border-sky-500/20">
              <Shield className="w-5 h-5" />
            </div>
            {!collapsed && (
              <div className="animate-fade-in">
                <div className="text-sm font-display font-bold text-white tracking-tight leading-none">ApexRisk</div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-sky-400 font-semibold">Underwriting</span>
              </div>
            )}
          </div>
          
          <button
            id="btn-toggle-sidebar"
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-400 hover:text-white transition-all shrink-0 cursor-pointer hidden md:block"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* User Card */}
        <div className={`p-4 border-b border-slate-800/50 bg-slate-950/20 ${collapsed ? "text-center" : ""}`}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-sky-400 to-blue-600 text-white flex items-center justify-center font-display font-semibold shrink-0">
              {user.name.charAt(0)}
            </div>
            {!collapsed && (
              <div className="overflow-hidden">
                <div className="text-xs font-semibold text-white truncate">{user.name}</div>
                <div className="text-[10px] text-slate-400 truncate flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${isAdmin ? "bg-amber-400 animate-pulse" : "bg-sky-400"}`} />
                  {isAdmin ? "Underwriter Admin" : "Lending Officer"}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Navigation lists */}
        <nav className="p-3 space-y-1.5">
          <div className={`text-[10px] font-bold text-slate-500 uppercase tracking-wider px-3 mb-2 ${collapsed ? "text-center" : ""}`}>
            {collapsed ? "Main" : "Operations"}
          </div>
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer group ${
                  isActive
                    ? "bg-sky-500 text-white shadow-lg shadow-sky-500/10 font-semibold"
                    : "hover:bg-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-105 ${isActive ? "text-white" : "text-slate-400"}`} />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}

          {/* Admin Station Navigation */}
          {isAdmin && (
            <div className="pt-4 space-y-1.5">
              <div className={`text-[10px] font-bold text-slate-500 uppercase tracking-wider px-3 mb-2 ${collapsed ? "text-center" : ""}`}>
                {collapsed ? "Admin" : "System Control"}
              </div>
              {adminNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-item-${item.id}`}
                    onClick={() => onTabChange(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer group ${
                      isActive
                        ? "bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/10 font-bold"
                        : "hover:bg-slate-800 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-105 ${isActive ? "text-slate-950" : "text-amber-500"}`} />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                  </button>
                );
              })}
            </div>
          )}
        </nav>
      </div>

      {/* Sidebar Footer */}
      <div className="p-3 border-t border-slate-800">
        <button
          id="btn-logout"
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium hover:bg-rose-500/10 hover:text-rose-400 text-slate-400 transition-all cursor-pointer group"
        >
          <LogOut className="w-4 h-4 shrink-0 text-slate-400 group-hover:text-rose-400 transition-colors" />
          {!collapsed && <span className="truncate">Sign Out</span>}
        </button>
      </div>
    </div>
  );
}
