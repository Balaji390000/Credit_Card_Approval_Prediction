/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { CheckCircle2, XCircle, ShieldAlert, FileText, ArrowLeft, ArrowUpRight, Activity, Cpu, Sparkles } from "lucide-react";
import { PredictionRecord } from "../types";

interface PredictionResultViewProps {
  record: PredictionRecord;
  onBackToForm: () => void;
  onGoToHistory: () => void;
}

export default function PredictionResultView({ record, onBackToForm, onGoToHistory }: PredictionResultViewProps) {
  const { input, result } = record;
  const isApproved = result.approved;
  const probPercent = Math.round(result.probability * 100);

  // SVG parameters for the Credit Risk Meter (circular gauge)
  // Radius: 50, Circumference: 2 * pi * 50 = 314.16
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  // Fill gauge proportional to approval probability
  const strokeDashoffset = circumference - (result.probability * circumference);

  // Colors for risk level
  const riskColorMap = {
    Low: "text-emerald-500 bg-emerald-50 border-emerald-100",
    Medium: "text-amber-500 bg-amber-50 border-amber-100",
    High: "text-rose-500 bg-rose-50 border-rose-100",
    Critical: "text-rose-700 bg-rose-100 border-rose-200",
  };

  const activeColor = isApproved ? "stroke-emerald-500" : "stroke-rose-500";
  const glowColor = isApproved ? "shadow-emerald-500/10" : "shadow-rose-500/10";

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Top action header */}
      <div className="flex justify-between items-center border-b border-slate-100 pb-4">
        <button
          id="btn-result-back"
          onClick={onBackToForm}
          className="text-xs font-semibold text-slate-500 hover:text-slate-800 transition-all flex items-center gap-1 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" /> New Application File
        </button>

        <span className="text-[10px] uppercase font-mono font-bold text-slate-400">
          Underwriting File ID: {record.id}
        </span>
      </div>

      {/* Primary Result Card */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left column: Decision and gauge meter */}
        <div className="md:col-span-5 bg-white rounded-2xl border border-slate-100 shadow-sm p-6 flex flex-col items-center justify-center text-center space-y-6">
          <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider">
            Lending Decision
          </span>

          {/* Large Decision Icon */}
          <div className="space-y-2">
            {isApproved ? (
              <div className="flex flex-col items-center">
                <CheckCircle2 className="w-16 h-16 text-emerald-500" />
                <h2 className="text-2xl font-display font-bold text-emerald-600 mt-3">APPROVED</h2>
                <p className="text-[10px] font-mono text-slate-400 uppercase">Credit limit issuance authorized</p>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <XCircle className="w-16 h-16 text-rose-500" />
                <h2 className="text-2xl font-display font-bold text-rose-600 mt-3">DECLINED</h2>
                <p className="text-[10px] font-mono text-slate-400 uppercase">Lending criteria variance</p>
              </div>
            )}
          </div>

          {/* Circular SVG Credit Risk Meter Gauge */}
          <div className="relative w-40 h-40 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              {/* Background circle */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                className="stroke-slate-100 fill-none"
                strokeWidth="8"
              />
              {/* Indicator circle */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                className={`${activeColor} fill-none transition-all duration-1000 ease-out`}
                strokeWidth="10"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="text-[9px] uppercase font-mono text-slate-400 font-bold">Credit Index</span>
              <span className="text-3xl font-display font-bold text-slate-900">{probPercent}%</span>
              <span className="text-[9px] font-mono text-slate-500 leading-none">Decision Score</span>
            </div>
          </div>

          {/* Quick Metrics Indicators */}
          <div className="w-full grid grid-cols-2 gap-4 border-t border-slate-50 pt-5 text-xs">
            <div className="space-y-1 border-r border-slate-50">
              <span className="text-[9px] uppercase text-slate-400 font-mono block">Risk Level</span>
              <span
                className={`inline-flex px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase border ${
                  riskColorMap[result.riskLevel]
                }`}
              >
                {result.riskLevel}
              </span>
            </div>
            <div className="space-y-1">
              <span className="text-[9px] uppercase text-slate-400 font-mono block">Model Conf.</span>
              <span className="font-mono font-bold text-slate-700">{result.confidenceScore}%</span>
            </div>
          </div>
        </div>

        {/* Right column: AI Underwriting Explanation & recommendations */}
        <div className="md:col-span-7 bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-50 pb-3">
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-500 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-display font-bold text-slate-900">
                Cognitive AI Credit Analysis
              </h3>
              <p className="text-[10px] text-slate-500 font-mono">POWERED BY GEMINI UNDERWRITING AGENT</p>
            </div>
          </div>

          {/* Detailed Narrative Explanation */}
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider block">
              Underwriting Narrative Summary
            </span>
            <p className="text-xs text-slate-600 font-light leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100 whitespace-pre-line">
              {result.aiExplanation}
            </p>
          </div>

          {/* Direct Recommendations */}
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider block">
              Roadmap & Credit Stabilization Advice
            </span>
            <div className="text-xs text-slate-600 font-light leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100 whitespace-pre-line">
              {result.recommendation}
            </div>
          </div>
        </div>
      </div>

      {/* Balances Sheet Solvency and Score Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Progress Health Score card */}
        <div className="md:col-span-4 border-b md:border-b-0 md:border-r border-slate-100 pb-5 md:pb-0 md:pr-6 space-y-3">
          <div>
            <span className="text-[9px] uppercase font-bold text-slate-400 font-mono tracking-wider">Financial Health Index</span>
            <div className="text-3xl font-display font-bold text-slate-900 mt-1">
              {result.financialHealthScore}<span className="text-xs text-slate-400 font-normal">/100</span>
            </div>
          </div>
          
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                result.financialHealthScore >= 75
                  ? "bg-emerald-500"
                  : result.financialHealthScore >= 50
                  ? "bg-amber-500"
                  : "bg-rose-500"
              }`}
              style={{ width: `${result.financialHealthScore}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400 font-light leading-normal">
            A comprehensive balance-sheet measure derived from debt-to-income, FICO credit standing, cash reserves, and job stability.
          </p>
        </div>

        {/* Quick parameters grid */}
        <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="space-y-1">
            <span className="text-[9px] uppercase text-slate-400 font-mono block">FICO Score</span>
            <span className="font-mono font-bold text-slate-800">{input.creditScore} Points</span>
          </div>
          <div className="space-y-1">
            <span className="text-[9px] uppercase text-slate-400 font-mono block">Monthly Income</span>
            <span className="font-mono font-bold text-slate-800">${Math.round(input.annualIncome / 12).toLocaleString()}</span>
          </div>
          <div className="space-y-1">
            <span className="text-[9px] uppercase text-slate-400 font-mono block">DTI Ratio</span>
            <span className="font-mono font-bold text-slate-800">
              {((input.monthlyEMI * 12 / (input.annualIncome || 1)) * 100).toFixed(1)}%
            </span>
          </div>
          <div className="space-y-1">
            <span className="text-[9px] uppercase text-slate-400 font-mono block">Savings-to-Debt</span>
            <span className="font-mono font-bold text-slate-800">
              {(input.bankBalance / (input.loanAmount || 1)).toFixed(2)}x
            </span>
          </div>
        </div>
      </div>

      {/* Action Footer Buttons */}
      <div className="flex justify-end gap-3 pt-2">
        <button
          id="btn-result-view-history"
          onClick={onGoToHistory}
          className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-all cursor-pointer inline-flex items-center gap-1.5"
        >
          View Full History Log <FileText className="w-4 h-4" />
        </button>
        
        <button
          id="btn-result-another"
          onClick={onBackToForm}
          className="px-5 py-2.5 bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold rounded-xl transition-all shadow-md shadow-sky-500/10 cursor-pointer inline-flex items-center gap-1.5"
        >
          Initiate New Audit <Activity className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
