/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as fs from "fs";
import * as path from "path";
import * as crypto from "crypto";
import { User, PredictionRecord, SystemLog, ContactMessage, RetrainingMetadata, PredictionInput, PredictionResult } from "../types";
import { getTrainedModelInstance } from "./mlEngine";

// Paths for JSON storage files to simulate enterprise SQLite tables
const DB_DIR = path.join(process.cwd(), "db_data");
const USERS_FILE = path.join(DB_DIR, "users.json");
const PREDICTIONS_FILE = path.join(DB_DIR, "predictions.json");
const LOGS_FILE = path.join(DB_DIR, "logs.json");
const CONTACT_FILE = path.join(DB_DIR, "contacts.json");
const METADATA_FILE = path.join(DB_DIR, "metadata.json");

// Helper to ensure database files exist
function ensureDB() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  const defaultFiles = [
    { file: USERS_FILE, default: [] },
    { file: PREDICTIONS_FILE, default: [] },
    { file: LOGS_FILE, default: [] },
    { file: CONTACT_FILE, default: [] },
  ];

  defaultFiles.forEach((item) => {
    if (!fs.existsSync(item.file)) {
      fs.writeFileSync(item.file, JSON.stringify(item.default, null, 2), "utf8");
    }
  });

  // Initialize Default Users (User & Admin)
  const users = JSON.parse(fs.readFileSync(USERS_FILE, "utf8")) as User[];
  if (users.length === 0) {
    // Admin Account
    const adminPasswordHash = crypto.createHash("sha256").update("admin123").digest("hex");
    const defaultAdmin: User = {
      id: "usr_admin",
      name: "Senior Risk Manager (Admin)",
      email: "admin@fintechbank.com",
      passwordHash: adminPasswordHash,
      role: "admin",
      createdAt: new Date().toISOString(),
    };

    // User Account
    const userPasswordHash = crypto.createHash("sha256").update("user123").digest("hex");
    const defaultUser: User = {
      id: "usr_standard",
      name: "Balaji Nidumolu (User)",
      email: "nidumolubalaji5@gmail.com", // From user metadata!
      passwordHash: userPasswordHash,
      role: "user",
      createdAt: new Date().toISOString(),
    };

    users.push(defaultAdmin, defaultUser);
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), "utf8");

    // Add first system log
    writeSystemLog("info", "Database initialized with default admin and user accounts.");
  }

  // Initialize ML Metadata file if absent
  if (!fs.existsSync(METADATA_FILE)) {
    const mlInstance = getTrainedModelInstance();
    fs.writeFileSync(METADATA_FILE, JSON.stringify(mlInstance.metadata, null, 2), "utf8");
  }
}

// Ensure database folders and files are created immediately on module load
ensureDB();

// ==========================================
// 1. GENERIC FILE READ/WRITE ACTIONS
// ==========================================

function readData<T>(filePath: string): T[] {
  try {
    ensureDB();
    const data = fs.readFileSync(filePath, "utf8");
    return JSON.parse(data) as T[];
  } catch (err) {
    console.error(`Error reading database file ${filePath}:`, err);
    return [];
  }
}

function writeData<T>(filePath: string, data: T[]) {
  try {
    ensureDB();
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
  } catch (err) {
    console.error(`Error writing database file ${filePath}:`, err);
  }
}

// ==========================================
// 2. USERS ENGINE
// ==========================================

export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

export function getAllUsers(): User[] {
  return readData<User>(USERS_FILE);
}

export function findUserByEmail(email: string): User | undefined {
  const users = getAllUsers();
  return users.find((u) => u.email.toLowerCase() === email.toLowerCase());
}

export function findUserById(id: string): User | undefined {
  const users = getAllUsers();
  return users.find((u) => u.id === id);
}

export function createUser(name: string, email: string, passwordPlain: string, role: "user" | "admin" = "user"): User {
  const users = getAllUsers();
  
  if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("A user with this email already exists");
  }

  const newUser: User = {
    id: `usr_${crypto.randomUUID().slice(0, 8)}`,
    name,
    email: email.toLowerCase(),
    passwordHash: hashPassword(passwordPlain),
    role,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  writeData(USERS_FILE, users);
  
  writeSystemLog("info", `New user registered: ${name} (${email})`, newUser.id);
  return newUser;
}

export function updateUserProfile(id: string, name: string, email: string): User {
  const users = getAllUsers();
  const userIdx = users.findIndex((u) => u.id === id);
  if (userIdx === -1) throw new Error("User not found");

  // Check if email already used by someone else
  const emailExists = users.some((u) => u.id !== id && u.email.toLowerCase() === email.toLowerCase());
  if (emailExists) throw new Error("Email already registered to another account");

  users[userIdx].name = name;
  users[userIdx].email = email.toLowerCase();
  writeData(USERS_FILE, users);

  writeSystemLog("info", `Profile updated for user: ${name}`, id);
  return users[userIdx];
}

export function changeUserPassword(id: string, newPasswordPlain: string) {
  const users = getAllUsers();
  const userIdx = users.findIndex((u) => u.id === id);
  if (userIdx === -1) throw new Error("User not found");

  users[userIdx].passwordHash = hashPassword(newPasswordPlain);
  writeData(USERS_FILE, users);

  writeSystemLog("info", `Password changed successfully.`, id);
}

export function deleteUserAccount(id: string) {
  let users = getAllUsers();
  const user = users.find((u) => u.id === id);
  if (!user) throw new Error("User not found");

  users = users.filter((u) => u.id !== id);
  writeData(USERS_FILE, users);

  // Clean up user's predictions as well to respect GDPR / Privacy
  let predictions = getAllPredictions();
  predictions = predictions.filter((p) => p.userId !== id);
  writeData(PREDICTIONS_FILE, predictions);

  writeSystemLog("warn", `Account deleted for user ID: ${id}`);
}

export function deleteUserByAdmin(id: string) {
  let users = getAllUsers();
  users = users.filter((u) => u.id !== id);
  writeData(USERS_FILE, users);

  writeSystemLog("warn", `Admin deleted user ID: ${id}`);
}

// ==========================================
// 3. PREDICTIONS & HISTORY ENGINE
// ==========================================

export function getAllPredictions(): PredictionRecord[] {
  return readData<PredictionRecord>(PREDICTIONS_FILE);
}

export function createPredictionRecord(
  userId: string,
  input: PredictionInput,
  result: PredictionResult
): PredictionRecord {
  const predictions = getAllPredictions();

  const record: PredictionRecord = {
    id: `tx_${crypto.randomUUID().slice(0, 8)}`,
    userId,
    applicantName: input.fullName,
    creditScore: input.creditScore,
    income: input.annualIncome,
    createdAt: new Date().toISOString(),
    input,
    result,
  };

  predictions.push(record);
  writeData(PREDICTIONS_FILE, predictions);

  writeSystemLog("info", `Prediction generated for ${input.fullName}. Decision: ${result.approved ? "APPROVED" : "REJECTED"}.`, userId);
  return record;
}

export function deletePredictionRecord(id: string) {
  let predictions = getAllPredictions();
  predictions = predictions.filter((p) => p.id !== id);
  writeData(PREDICTIONS_FILE, predictions);
  writeSystemLog("warn", `Prediction record deleted: ${id}`);
}

// ==========================================
// 4. METADATA RETRAINING MANAGEMENT
// ==========================================

export function getMetadata(): RetrainingMetadata {
  ensureDB();
  const data = fs.readFileSync(METADATA_FILE, "utf8");
  return JSON.parse(data) as RetrainingMetadata;
}

export function saveMetadata(metadata: RetrainingMetadata) {
  ensureDB();
  fs.writeFileSync(METADATA_FILE, JSON.stringify(metadata, null, 2), "utf8");
}

// ==========================================
// 5. SYSTEM LOGS ENGINE
// ==========================================

export function writeSystemLog(level: "info" | "warn" | "error", message: string, userId?: string, ip?: string) {
  const logs = readData<SystemLog>(LOGS_FILE);
  const newLog: SystemLog = {
    id: `log_${crypto.randomUUID().slice(0, 10)}`,
    timestamp: new Date().toISOString(),
    level,
    message,
    userId,
    ip,
  };

  logs.push(newLog);
  // Keep logs list pruned to last 200 items to conserve space
  if (logs.length > 200) {
    logs.shift();
  }
  writeData(LOGS_FILE, logs);
}

export function getAllLogs(): SystemLog[] {
  return readData<SystemLog>(LOGS_FILE);
}

// ==========================================
// 6. CONTACT MESSAGES ENGINE
// ==========================================

export function createContactMessage(name: string, email: string, subject: string, message: string): ContactMessage {
  const contacts = readData<ContactMessage>(CONTACT_FILE);
  const newContact: ContactMessage = {
    id: `msg_${crypto.randomUUID().slice(0, 8)}`,
    name,
    email: email.toLowerCase(),
    subject,
    message,
    createdAt: new Date().toISOString(),
  };

  contacts.push(newContact);
  writeData(CONTACT_FILE, contacts);

  writeSystemLog("info", `Contact form inquiry submitted from ${name} (${email})`);
  return newContact;
}

export function getContactMessages(): ContactMessage[] {
  return readData<ContactMessage>(CONTACT_FILE);
}
