/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PredictionInput, ModelMetrics, RetrainingMetadata } from "../types";

// ==========================================
// 1. DATASET DEFINITION & GENERATOR
// ==========================================

// Historical samples for initial model training
interface HistoricalSample extends PredictionInput {
  approved: boolean;
}

// Generate highly realistic synthetic historical data (200 records)
function generateHistoricalDataset(): HistoricalSample[] {
  const samples: HistoricalSample[] = [];
  const genders = ["Male", "Female"];
  const maritalStatuses = ["Single", "Married", "Divorced"];
  const educations = ["High School", "Associate", "Bachelor", "Master", "PhD"];
  const employments = ["Employed", "Self-Employed", "Retired", "Student", "Unemployed"];
  const existingLoansOpts = ["none", "one", "multiple"];
  const properties = ["own", "rent", "mortgage"];
  
  const occupationsMap: Record<string, string[]> = {
    "Employed": ["Software Engineer", "Manager", "Teacher", "Nurse", "Accountant", "Sales Representative"],
    "Self-Employed": ["Business Owner", "Consultant", "Freelancer", "Contractor"],
    "Retired": ["Retired Analyst", "Retired Officer", "Pensioner"],
    "Student": ["Graduate Student", "College Student"],
    "Unemployed": ["Unemployed", "Between Jobs"]
  };

  // Seeded random number generator for reproducibility
  let seed = 42;
  function random(): number {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  }
  
  function getRandomElement<T>(arr: T[]): T {
    return arr[Math.floor(random() * arr.length)];
  }

  for (let i = 0; i < 200; i++) {
    const gender = getRandomElement(genders);
    const maritalStatus = getRandomElement(maritalStatuses);
    const education = getRandomElement(educations);
    const employmentStatus = getRandomElement(employments);
    const occupation = getRandomElement(occupationsMap[employmentStatus] || ["Other"]);
    const existingLoans = getRandomElement(existingLoansOpts);
    const propertyOwnership = getRandomElement(properties);

    // Numeric continuous values
    const age = Math.floor(21 + random() * 50);
    const yearsOfEmployment = employmentStatus === "Employed" || employmentStatus === "Self-Employed"
      ? Math.floor(1 + random() * 20)
      : 0;
      
    // Income correlates with age, education and employment
    let baseIncome = 25000;
    if (education === "Master" || education === "PhD") baseIncome += 30000;
    if (education === "Bachelor") baseIncome += 15000;
    if (employmentStatus === "Unemployed" || employmentStatus === "Student") baseIncome = 8000;
    const annualIncome = Math.floor(baseIncome + random() * 90000);

    // Credit score
    let creditScore = Math.floor(500 + random() * 320);
    if (existingLoans === "multiple") creditScore -= 50;
    if (annualIncome > 80000) creditScore += 40;
    creditScore = Math.max(300, Math.min(850, creditScore));

    // Bank balance correlates with income and credit score
    const bankBalance = Math.floor((annualIncome * 0.15) + (random() * annualIncome * 0.5) + (creditScore > 700 ? 15000 : 0));

    // Loan details
    const loanAmount = Math.floor(10000 + random() * 150000);
    const monthlyEMI = Math.floor((loanAmount * 0.008) + random() * 200);
    const numDependents = Math.floor(random() * 4);

    const email = `applicant_${i}@example.com`;
    const fullName = `${gender === "Male" ? "John" : "Jane"} Doe ${i}`;

    const input: PredictionInput = {
      fullName,
      email,
      gender,
      age,
      maritalStatus,
      education,
      employmentStatus,
      occupation,
      yearsOfEmployment,
      annualIncome,
      creditScore,
      existingLoans,
      loanAmount,
      monthlyEMI,
      propertyOwnership,
      numDependents,
      bankBalance,
    };

    // Credit approval decision logic (Ground Truth Label with some noise)
    // Strong predictors: creditScore, debt-to-income, bank balance, employment
    let score = 0;
    if (creditScore >= 700) score += 4.5;
    else if (creditScore >= 640) score += 2.0;
    else if (creditScore < 580) score -= 3.0;

    const debtToIncomeRatio = (monthlyEMI * 12) / annualIncome;
    if (debtToIncomeRatio < 0.2) score += 1.5;
    else if (debtToIncomeRatio > 0.45) score -= 2.0;

    if (bankBalance > 20000) score += 1.5;
    if (yearsOfEmployment >= 3) score += 1.0;
    if (employmentStatus === "Unemployed") score -= 2.5;
    if (existingLoans === "multiple") score -= 1.0;

    // Standard deviation and noise
    const probability = 1 / (1 + Math.exp(-score));
    const approved = (probability + (random() - 0.5) * 0.15) >= 0.5;

    samples.push({ ...input, approved });
  }

  return samples;
}

// ==========================================
// 2. FEATURE ENGINEERING & PREPROCESSING
// ==========================================

export interface PreprocessorConfig {
  mean: Record<string, number>;
  std: Record<string, number>;
  categoricalMappings: Record<string, Record<string, number>>;
  featureNames: string[];
}

export function preprocessDataset(
  samples: HistoricalSample[]
): { X: number[][]; y: number[]; config: PreprocessorConfig } {
  // Define features to extract
  const numericFeatures = [
    "age",
    "yearsOfEmployment",
    "annualIncome",
    "creditScore",
    "loanAmount",
    "monthlyEMI",
    "bankBalance",
    "numDependents",
  ];

  const categoricalFeatures = [
    "gender",
    "maritalStatus",
    "education",
    "employmentStatus",
    "existingLoans",
    "propertyOwnership",
  ];

  // Define maps for categorical features (Label Encoding)
  const categoricalMappings: Record<string, Record<string, number>> = {
    gender: { "Male": 1, "Female": 0 },
    maritalStatus: { "Single": 0, "Married": 1, "Divorced": 2 },
    education: { "High School": 0, "Associate": 1, "Bachelor": 2, "Master": 3, "PhD": 4 },
    employmentStatus: { "Unemployed": 0, "Student": 1, "Retired": 2, "Self-Employed": 3, "Employed": 4 },
    existingLoans: { "none": 0, "one": 1, "multiple": 2 },
    propertyOwnership: { "rent": 0, "mortgage": 1, "own": 2 },
  };

  // Convert samples to feature vectors
  const X_raw: number[][] = [];
  const y: number[] = [];

  samples.forEach((sample) => {
    const row: number[] = [];
    
    // 1. Numeric features with fallback for safety
    numericFeatures.forEach((feat) => {
      let val = sample[feat as keyof PredictionInput] as number;
      if (typeof val !== "number" || isNaN(val)) val = 0; // Missing value handling
      row.push(val);
    });

    // 2. Categorical features
    categoricalFeatures.forEach((feat) => {
      const valStr = String(sample[feat as keyof PredictionInput]);
      const mapping = categoricalMappings[feat];
      const encodedVal = mapping && valStr in mapping ? mapping[valStr] : 0;
      row.push(encodedVal);
    });

    X_raw.push(row);
    y.push(sample.approved ? 1 : 0);
  });

  const featureNames = [...numericFeatures, ...categoricalFeatures];

  // Feature Scaling (Standardization: (x - mean) / std)
  const mean: Record<string, number> = {};
  const std: Record<string, number> = {};
  const X_scaled: number[][] = [];

  const numRows = X_raw.length;
  const numCols = featureNames.length;

  for (let col = 0; col < numCols; col++) {
    const colName = featureNames[col];
    
    // Mean
    let sum = 0;
    for (let row = 0; row < numRows; row++) {
      sum += X_raw[row][col];
    }
    const colMean = sum / numRows;
    mean[colName] = colMean;

    // Std
    let sumSquaredDiff = 0;
    for (let row = 0; row < numRows; row++) {
      sumSquaredDiff += Math.pow(X_raw[row][col] - colMean, 2);
    }
    const colStd = Math.sqrt(sumSquaredDiff / numRows) || 1; // avoid division by zero
    std[colName] = colStd;
  }

  // Scale every value
  for (let row = 0; row < numRows; row++) {
    const scaledRow: number[] = [];
    for (let col = 0; col < numCols; col++) {
      const colName = featureNames[col];
      const scaledVal = (X_raw[row][col] - mean[colName]) / std[colName];
      scaledRow.push(scaledVal);
    }
    X_scaled.push(scaledRow);
  }

  return {
    X: X_scaled,
    y,
    config: {
      mean,
      std,
      categoricalMappings,
      featureNames,
    },
  };
}

export function preprocessSingleInput(
  input: PredictionInput,
  config: PreprocessorConfig
): number[] {
  const numericFeatures = [
    "age",
    "yearsOfEmployment",
    "annualIncome",
    "creditScore",
    "loanAmount",
    "monthlyEMI",
    "bankBalance",
    "numDependents",
  ];

  const categoricalFeatures = [
    "gender",
    "maritalStatus",
    "education",
    "employmentStatus",
    "existingLoans",
    "propertyOwnership",
  ];

  const row: number[] = [];

  // Numeric values
  numericFeatures.forEach((feat) => {
    let val = input[feat as keyof PredictionInput] as number;
    if (typeof val !== "number" || isNaN(val)) val = 0;
    row.push(val);
  });

  // Categorical values
  categoricalFeatures.forEach((feat) => {
    const valStr = String(input[feat as keyof PredictionInput]);
    const mapping = config.categoricalMappings[feat];
    const encodedVal = mapping && valStr in mapping ? mapping[valStr] : 0;
    row.push(encodedVal);
  });

  // Scale using saved means and stds
  const scaledRow: number[] = [];
  for (let col = 0; col < config.featureNames.length; col++) {
    const colName = config.featureNames[col];
    const meanVal = config.mean[colName];
    const stdVal = config.std[colName];
    const scaledVal = (row[col] - meanVal) / stdVal;
    scaledRow.push(scaledVal);
  }

  return scaledRow;
}

// ==========================================
// 3. MACHINE LEARNING MODEL IMPLEMENTATIONS
// ==========================================

export interface TrainedModel {
  predictProbability: (x: number[]) => number;
  weights?: number[];
  bias?: number;
  tree?: any;
  trees?: any[];
  importances: number[];
}

// 3.1. Logistic Regression
function trainLogisticRegression(X: number[][], y: number[]): TrainedModel {
  const numFeatures = X[0].length;
  const weights = new Array(numFeatures).fill(0).map(() => (Math.random() - 0.5) * 0.1);
  let bias = 0;
  const learningRate = 0.05;
  const epochs = 150;

  for (let epoch = 0; epoch < epochs; epoch++) {
    for (let i = 0; i < X.length; i++) {
      const xi = X[i];
      const yi = y[i];

      // Predict sigmoid(w*x + b)
      let dot = 0;
      for (let j = 0; j < numFeatures; j++) {
        dot += xi[j] * weights[j];
      }
      const linear = dot + bias;
      const pred = 1 / (1 + Math.exp(-linear));

      // Gradients
      const error = pred - yi;
      for (let j = 0; j < numFeatures; j++) {
        weights[j] -= learningRate * error * xi[j];
      }
      bias -= learningRate * error;
    }
  }

  // Feature Importance for Logistic Regression is proportional to absolute weights
  const totalWeight = weights.reduce((sum, w) => sum + Math.abs(w), 0) || 1;
  const importances = weights.map((w) => Math.abs(w) / totalWeight);

  return {
    predictProbability: (x) => {
      let dot = 0;
      for (let j = 0; j < x.length; j++) {
        dot += x[j] * weights[j];
      }
      const linear = dot + bias;
      return 1 / (1 + Math.exp(-linear));
    },
    weights,
    bias,
    importances,
  };
}

// 3.2. Decision Tree Classifier
interface DecisionTreeNode {
  featureIndex?: number;
  threshold?: number;
  left?: DecisionTreeNode | null;
  right?: DecisionTreeNode | null;
  value?: number; // predicted probability / outcome if leaf
  isLeaf: boolean;
}

function trainDecisionTree(X: number[][], y: number[], maxDepth = 4): TrainedModel {
  const numFeatures = X[0].length;

  function calculateGini(labels: number[]): number {
    const total = labels.length;
    if (total === 0) return 0;
    let positives = 0;
    for (let i = 0; i < total; i++) {
      if (labels[i] === 1) positives++;
    }
    const p1 = positives / total;
    const p0 = 1 - p1;
    return 1 - (p1 * p1 + p0 * p0);
  }

  const importances = new Array(numFeatures).fill(0);

  function buildTree(indices: number[], depth: number): DecisionTreeNode {
    const labels = indices.map((idx) => y[idx]);
    const positives = labels.filter((lbl) => lbl === 1).length;
    const size = indices.length;

    // Base conditions for leaf node
    if (depth >= maxDepth || size <= 4 || positives === 0 || positives === size) {
      return {
        isLeaf: true,
        value: size > 0 ? positives / size : 0,
      };
    }

    let bestGiniGain = -1;
    let bestFeature = -1;
    let bestThreshold = 0;
    let bestLeftIndices: number[] = [];
    let bestRightIndices: number[] = [];

    const currentGini = calculateGini(labels);

    // Grid search best split
    for (let f = 0; f < numFeatures; f++) {
      // Collect values for this feature
      const featureValues = indices.map((idx) => X[idx][f]);
      // Sort and evaluate midpoints
      const sortedVals = Array.from(new Set(featureValues)).sort((a, b) => a - b);
      
      for (let t = 0; t < sortedVals.length - 1; t++) {
        const threshold = (sortedVals[t] + sortedVals[t + 1]) / 2;
        
        const left: number[] = [];
        const right: number[] = [];
        
        indices.forEach((idx) => {
          if (X[idx][f] <= threshold) left.push(idx);
          else right.push(idx);
        });

        if (left.length === 0 || right.length === 0) continue;

        const leftGini = calculateGini(left.map((idx) => y[idx]));
        const rightGini = calculateGini(right.map((idx) => y[idx]));
        
        const splitGini = (left.length / size) * leftGini + (right.length / size) * rightGini;
        const giniGain = currentGini - splitGini;

        if (giniGain > bestGiniGain) {
          bestGiniGain = giniGain;
          bestFeature = f;
          bestThreshold = threshold;
          bestLeftIndices = left;
          bestRightIndices = right;
        }
      }
    }

    if (bestFeature === -1) {
      return {
        isLeaf: true,
        value: positives / size,
      };
    }

    // Accumulate feature importance based on split gain
    importances[bestFeature] += bestGiniGain * size;

    return {
      isLeaf: false,
      featureIndex: bestFeature,
      threshold: bestThreshold,
      left: buildTree(bestLeftIndices, depth + 1),
      right: buildTree(bestRightIndices, depth + 1),
    };
  }

  const initialIndices = Array.from({ length: X.length }, (_, i) => i);
  const root = buildTree(initialIndices, 0);

  // Normalize feature importance
  const sumImportances = importances.reduce((s, val) => s + val, 0) || 1;
  const normalizedImportances = importances.map((val) => val / sumImportances);

  function predictRow(node: DecisionTreeNode, row: number[]): number {
    if (node.isLeaf) return node.value || 0;
    const featVal = row[node.featureIndex!];
    if (featVal <= node.threshold!) {
      return predictRow(node.left!, row);
    } else {
      return predictRow(node.right!, row);
    }
  }

  return {
    predictProbability: (x) => predictRow(root, x),
    tree: root,
    importances: normalizedImportances,
  };
}

// 3.3. Random Forest (Bootstrap aggregating over trees)
function trainRandomForest(X: number[][], y: number[]): TrainedModel {
  const numTrees = 5;
  const numFeatures = X[0].length;
  const trees: TrainedModel[] = [];
  const forestImportances = new Array(numFeatures).fill(0);

  // Seeded random
  let seed = 123;
  function random(): number {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  }

  for (let t = 0; t < numTrees; t++) {
    // Generate bootstrap sample (with replacement)
    const bootstrapX: number[][] = [];
    const bootstrapY: number[] = [];
    for (let i = 0; i < X.length; i++) {
      const idx = Math.floor(random() * X.length);
      bootstrapX.push(X[idx]);
      bootstrapY.push(y[idx]);
    }

    // Train a decision tree on this bootstrap sample
    const tree = trainDecisionTree(bootstrapX, bootstrapY, 4);
    trees.push(tree);

    // Accumulate feature importances
    for (let f = 0; f < numFeatures; f++) {
      forestImportances[f] += tree.importances[f];
    }
  }

  // Normalize importances
  const sumImportances = forestImportances.reduce((s, v) => s + v, 0) || 1;
  const normalizedImportances = forestImportances.map((v) => v / sumImportances);

  return {
    predictProbability: (x) => {
      let sumProb = 0;
      trees.forEach((tree) => {
        sumProb += tree.predictProbability(x);
      });
      return sumProb / numTrees;
    },
    trees,
    importances: normalizedImportances,
  };
}

// 3.4. Support Vector Machine (Linear SVM with Gradient Descent)
function trainSVM(X: number[][], y: number[]): TrainedModel {
  const numFeatures = X[0].length;
  const weights = new Array(numFeatures).fill(0).map(() => (Math.random() - 0.5) * 0.1);
  let bias = 0;
  const lr = 0.01;
  const lambda = 0.05; // L2 Regularization parameter
  const epochs = 150;

  // Map 0/1 labels to -1/+1 for standard hinge-loss SVM
  const y_svm = y.map((label) => (label === 1 ? 1 : -1));

  for (let epoch = 0; epoch < epochs; epoch++) {
    for (let i = 0; i < X.length; i++) {
      const xi = X[i];
      const yi = y_svm[i];

      let score = 0;
      for (let j = 0; j < numFeatures; j++) {
        score += xi[j] * weights[j];
      }
      score += bias;

      const condition = yi * score >= 1;

      for (let j = 0; j < numFeatures; j++) {
        if (condition) {
          // Regularization gradient update
          weights[j] -= lr * (2 * lambda * weights[j]);
        } else {
          // Regularization + hinge loss gradient update
          weights[j] -= lr * (2 * lambda * weights[j] - yi * xi[j]);
        }
      }
      if (!condition) {
        bias += lr * yi;
      }
    }
  }

  // Compute absolute weights for feature importance
  const totalWeight = weights.reduce((sum, w) => sum + Math.abs(w), 0) || 1;
  const importances = weights.map((w) => Math.abs(w) / totalWeight);

  return {
    predictProbability: (x) => {
      let dot = 0;
      for (let j = 0; j < x.length; j++) {
        dot += x[j] * weights[j];
      }
      const score = dot + bias;
      // Map linear score to probability using sigmoid function
      return 1 / (1 + Math.exp(-score * 1.5));
    },
    weights,
    bias,
    importances,
  };
}

// 3.5. XGBoost (Gradient Boosting on Trees)
function trainXGBoost(X: number[][], y: number[]): TrainedModel {
  const numBoosts = 4;
  const numFeatures = X[0].length;
  const trees: TrainedModel[] = [];
  const learningRate = 0.1;
  
  // Set initial predictions (mean of outcomes)
  const initialPred = y.reduce((s, v) => s + v, 0) / y.length;
  const currentPreds = new Array(X.length).fill(initialPred);

  const xgboostImportances = new Array(numFeatures).fill(0);

  for (let b = 0; b < numBoosts; b++) {
    // Calculate gradients (residuals: y - predicted_probability)
    const residuals = y.map((yi, idx) => {
      const prob = 1 / (1 + Math.exp(-currentPreds[idx]));
      return yi - prob;
    });

    // Train a weak decision tree on the residuals
    // (Here residuals act as continuous targets, we simplify by scaling labels)
    // Map continuous residuals to binary target labels around zero for tree split logic
    const mappedY = residuals.map((r) => (r >= 0 ? 1 : 0));
    const tree = trainDecisionTree(X, mappedY, 3);
    trees.push(tree);

    // Update current predictions
    for (let i = 0; i < X.length; i++) {
      const step = tree.predictProbability(X[i]) - 0.5; // shift around zero
      currentPreds[i] += learningRate * step * 2;
    }

    // Accumulate feature importances
    for (let f = 0; f < numFeatures; f++) {
      xgboostImportances[f] += tree.importances[f];
    }
  }

  // Normalize importances
  const sumImportances = xgboostImportances.reduce((s, v) => s + v, 0) || 1;
  const normalizedImportances = xgboostImportances.map((v) => v / sumImportances);

  return {
    predictProbability: (x) => {
      let score = Math.log(initialPred / (1 - initialPred || 1));
      if (isNaN(score) || !isFinite(score)) score = 0;

      trees.forEach((tree) => {
        const step = tree.predictProbability(x) - 0.5;
        score += learningRate * step * 2;
      });

      return 1 / (1 + Math.exp(-score));
    },
    trees,
    importances: normalizedImportances,
  };
}

// ==========================================
// 4. PIPELINE AND COMPARISON ENGINE
// ==========================================

export function evaluateModel(
  model: TrainedModel,
  X_test: number[][],
  y_test: number[],
  featureNames: string[]
): ModelMetrics {
  let tp = 0, fp = 0, tn = 0, fn = 0;
  const scores: { probability: number; label: number }[] = [];

  for (let i = 0; i < X_test.length; i++) {
    const prob = model.predictProbability(X_test[i]);
    const pred = prob >= 0.5 ? 1 : 0;
    const actual = y_test[i];

    scores.push({ probability: prob, label: actual });

    if (actual === 1 && pred === 1) tp++;
    else if (actual === 1 && pred === 0) fn++;
    else if (actual === 0 && pred === 1) fp++;
    else if (actual === 0 && pred === 0) tn++;
  }

  const accuracy = (tp + tn) / X_test.length;
  const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
  const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
  const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

  // Generate ROC Curve points (varying thresholds from 0 to 1)
  const rocCurve: { fpr: number; tpr: number }[] = [];
  
  // Sort thresholds for standard ROC plotting
  const sortedScores = [...scores].sort((a, b) => b.probability - a.probability);
  const totalPos = y_test.filter(lbl => lbl === 1).length || 1;
  const totalNeg = y_test.length - totalPos || 1;

  let currentTp = 0;
  let currentFp = 0;

  rocCurve.push({ fpr: 0, tpr: 0 });
  for (let i = 0; i < sortedScores.length; i++) {
    if (sortedScores[i].label === 1) {
      currentTp++;
    } else {
      currentFp++;
    }
    rocCurve.push({
      fpr: currentFp / totalNeg,
      tpr: currentTp / totalPos,
    });
  }
  rocCurve.push({ fpr: 1, tpr: 1 });

  // Map features to importance
  const featureImportance = featureNames.map((name, idx) => ({
    feature: name,
    importance: model.importances[idx] || 0,
  })).sort((a, b) => b.importance - a.importance);

  return {
    accuracy,
    precision,
    recall,
    f1,
    confusionMatrix: [
      [tn, fp],
      [fn, tp],
    ],
    rocCurve,
    featureImportance,
  };
}

// Runs Train/Test Split, trains 5 models, and compares them
export function trainAndCompareAllModels(): RetrainingMetadata {
  const rawSamples = generateHistoricalDataset();
  const { X, y, config } = preprocessDataset(rawSamples);

  // Train/Test Split (75% / 25%)
  const splitIdx = Math.floor(X.length * 0.75);
  const X_train = X.slice(0, splitIdx);
  const y_train = y.slice(0, splitIdx);
  const X_test = X.slice(splitIdx);
  const y_test = y.slice(splitIdx);

  // Train 5 models
  const modelLogistic = trainLogisticRegression(X_train, y_train);
  const modelDecisionTree = trainDecisionTree(X_train, y_train);
  const modelRandomForest = trainRandomForest(X_train, y_train);
  const modelSVM = trainSVM(X_train, y_train);
  const modelXGBoost = trainXGBoost(X_train, y_train);

  // Evaluate models
  const compare: Record<string, ModelMetrics> = {
    "Logistic Regression": evaluateModel(modelLogistic, X_test, y_test, config.featureNames),
    "Decision Tree": evaluateModel(modelDecisionTree, X_test, y_test, config.featureNames),
    "Random Forest": evaluateModel(modelRandomForest, X_test, y_test, config.featureNames),
    "SVM": evaluateModel(modelSVM, X_test, y_test, config.featureNames),
    "XGBoost": evaluateModel(modelXGBoost, X_test, y_test, config.featureNames),
  };

  // Determine active model based on best F1 score
  let bestModelName = "Random Forest";
  let bestF1 = 0;
  Object.entries(compare).forEach(([name, metrics]) => {
    if (metrics.f1 > bestF1) {
      bestF1 = metrics.f1;
      bestModelName = name;
    }
  });

  return {
    trainedAt: new Date().toISOString(),
    activeModel: bestModelName,
    datasetSize: rawSamples.length,
    modelComparison: compare,
  };
}

// Singleton Cache for trained model structures (mocking model.pkl and scaler.pkl)
let activeModelCache: {
  config: PreprocessorConfig;
  model: TrainedModel;
  metadata: RetrainingMetadata;
} | null = null;

export function getTrainedModelInstance() {
  if (!activeModelCache) {
    const metadata = trainAndCompareAllModels();
    const rawSamples = generateHistoricalDataset();
    const { X, y, config } = preprocessDataset(rawSamples);

    // Train the designated best model on full data for production use
    let model: TrainedModel;
    switch (metadata.activeModel) {
      case "Logistic Regression":
        model = trainLogisticRegression(X, y);
        break;
      case "Decision Tree":
        model = trainDecisionTree(X, y);
        break;
      case "SVM":
        model = trainSVM(X, y);
        break;
      case "XGBoost":
        model = trainXGBoost(X, y);
        break;
      case "Random Forest":
      default:
        model = trainRandomForest(X, y);
        break;
    }

    activeModelCache = {
      config,
      model,
      metadata,
    };
  }

  return activeModelCache;
}

export function retrainPipeline(): RetrainingMetadata {
  activeModelCache = null; // Invalidate cache
  const instance = getTrainedModelInstance();
  return instance.metadata;
}

export function predictApproval(input: PredictionInput): {
  approved: boolean;
  probability: number;
  confidenceScore: number;
  riskLevel: "Low" | "Medium" | "High" | "Critical";
  financialHealthScore: number;
  activeModelUsed: string;
} {
  const instance = getTrainedModelInstance();
  const scaledFeatures = preprocessSingleInput(input, instance.config);
  const probability = instance.model.predictProbability(scaledFeatures);
  const approved = probability >= 0.5;

  // Risk Level assessment
  // Lower credit scores & higher debt-to-income increase risk
  let riskScore = 0;
  if (input.creditScore < 580) riskScore += 3;
  else if (input.creditScore < 640) riskScore += 2;
  else if (input.creditScore < 700) riskScore += 1;

  const dti = (input.monthlyEMI * 12) / (input.annualIncome || 1);
  if (dti > 0.45) riskScore += 3;
  else if (dti > 0.3) riskScore += 2;
  else if (dti > 0.15) riskScore += 1;

  if (input.bankBalance < 5000) riskScore += 2;
  if (input.employmentStatus === "Unemployed") riskScore += 2;

  let riskLevel: "Low" | "Medium" | "High" | "Critical" = "Low";
  if (riskScore >= 7) riskLevel = "Critical";
  else if (riskScore >= 4) riskLevel = "High";
  else if (riskScore >= 2) riskLevel = "Medium";

  // Financial Health Score (0-100)
  // Calculated from credit score (40%), debt-to-income (30%), saving ratio (20%), and employment stability (10%)
  const creditScoreNorm = ((input.creditScore - 300) / 550) * 100;
  const dtiScoreNorm = Math.max(0, (1 - dti) * 100);
  const savingsScoreNorm = Math.min(100, (input.bankBalance / (input.annualIncome * 0.1 || 10000)) * 100);
  const empStabilityNorm = input.yearsOfEmployment >= 5 ? 100 : input.yearsOfEmployment * 20;

  const financialHealthScore = Math.round(
    creditScoreNorm * 0.4 +
    dtiScoreNorm * 0.3 +
    savingsScoreNorm * 0.2 +
    empStabilityNorm * 0.1
  );

  // Confidence score is derived from mathematical distance from the decision boundary
  const confidenceScore = Math.round(50 + Math.abs(probability - 0.5) * 100);

  return {
    approved,
    probability,
    confidenceScore,
    riskLevel,
    financialHealthScore: Math.max(0, Math.min(100, financialHealthScore)),
    activeModelUsed: instance.metadata.activeModel,
  };
}
