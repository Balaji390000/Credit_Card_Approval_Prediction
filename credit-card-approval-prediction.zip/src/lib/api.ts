/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

let tokenCache = typeof window !== "undefined" ? localStorage.getItem("cc_auth_token") || "" : "";

export function setToken(token: string) {
  tokenCache = token;
  if (typeof window !== "undefined") {
    localStorage.setItem("cc_auth_token", token);
  }
}

export function getToken(): string {
  if (!tokenCache && typeof window !== "undefined") {
    tokenCache = localStorage.getItem("cc_auth_token") || "";
  }
  return tokenCache;
}

export function clearToken() {
  tokenCache = "";
  if (typeof window !== "undefined") {
    localStorage.removeItem("cc_auth_token");
  }
}

export async function apiFetch<T = any>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  
  const headers = new Headers(options.headers || {});
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  if (!(options.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `HTTP error ${response.status}: ${response.statusText}`);
  }

  return response.json() as Promise<T>;
}
