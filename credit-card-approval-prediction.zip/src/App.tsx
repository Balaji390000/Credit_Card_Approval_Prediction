/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Shield,
  Key,
  Mail,
  User as UserIcon,
  Moon,
  Sun,
  LogOut,
  ChevronRight,
  Sparkles,
  ChevronLeft,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  Menu,
  X
} from "lucide-react";
import { apiFetch, setToken, getToken, clearToken } from "./lib/api";
import { User, PredictionRecord } from "./types";

// Component imports
import LandingView from "./components/LandingView";
import Sidebar from "./components/Sidebar";
import DashboardView from "./components/DashboardView";
import PredictionFormView from "./components/PredictionFormView";
import PredictionResultView from "./components/PredictionResultView";
import HistoryView from "./components/HistoryView";
import AnalyticsView from "./components/AnalyticsView";
import ProfileView from "./components/ProfileView";
import AdminView from "./components/AdminView";

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Navigation states
  const [currentView, setCurrentView] = useState<"landing" | "login" | "register" | "forgot" | "dashboard">("landing");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Active prediction results mapping (to toggle between form and results)
  const [activePrediction, setActivePrediction] = useState<PredictionRecord | null>(null);

  // Dark Mode State
  const [darkMode, setDarkMode] = useState(false);

  // Authentication Forms State
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regRole, setRegRole] = useState<"reviewer" | "admin">("reviewer");
  const [forgotEmail, setForgotEmail] = useState("");
  
  // Form feedback alert messages
  const [authError, setAuthError] = useState("");
  const [authSuccess, setAuthSuccess] = useState("");
  const [authSubmitting, setAuthSubmitting] = useState(false);

  // Initialize session and verify token
  useEffect(() => {
    async function verifySession() {
      const token = getToken();
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const user = await apiFetch<User>("/api/auth/me");
        setCurrentUser(user);
        setCurrentView("dashboard");
      } catch (err) {
        clearToken();
        setCurrentUser(null);
        setCurrentView("landing");
      } finally {
        setLoading(false);
      }
    }

    verifySession();
  }, []);

  // Sync Dark Mode state to document root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      setAuthError("Please fill out both credentials fields.");
      return;
    }

    setAuthSubmitting(true);
    setAuthError("");
    setAuthSuccess("");

    try {
      const response = await apiFetch("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });
      setToken(response.token);
      setCurrentUser(response.user);
      setAuthSuccess("Authentication authorized.");
      
      // Clear forms
      setLoginEmail("");
      setLoginPassword("");
      
      // Go to inner dashboard panel
      setCurrentView("dashboard");
      setActiveTab("dashboard");
    } catch (err: any) {
      setAuthError(err.message || "Invalid authentication credentials.");
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail || !regPassword) {
      setAuthError("Please complete all registry registration fields.");
      return;
    }

    setAuthSubmitting(true);
    setAuthError("");
    setAuthSuccess("");

    try {
      const response = await apiFetch("/api/auth/register", {
        method: "POST",
        body: JSON.stringify({ name: regName, email: regEmail, password: regPassword, role: regRole }),
      });
      setToken(response.token);
      setCurrentUser(response.user);
      setAuthSuccess("Registration authorized successfully.");
      
      // Clear forms
      setRegName("");
      setRegEmail("");
      setRegPassword("");
      
      setCurrentView("dashboard");
      setActiveTab("dashboard");
    } catch (err: any) {
      setAuthError(err.message || "Registration failed. Email may already be registered.");
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) {
      setAuthError("Please input your registered email address.");
      return;
    }

    setAuthSubmitting(true);
    setAuthError("");
    setAuthSuccess("");

    try {
      await apiFetch("/api/auth/forgot-password", {
        method: "POST",
        body: JSON.stringify({ email: forgotEmail }),
      });
      setAuthSuccess("A reset link simulation has been logged. For development ease, you can instantly register another account.");
      setForgotEmail("");
    } catch (err: any) {
      setAuthError(err.message || "Failed to trigger reset verification.");
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleLogout = () => {
    clearToken();
    setCurrentUser(null);
    setCurrentView("landing");
    setActiveTab("dashboard");
    setActivePrediction(null);
  };

  // Navigating to direct reports from History or Dashboard
  const handleSelectReport = (record: PredictionRecord) => {
    setActivePrediction(record);
    setActiveTab("prediction");
    setMobileMenuOpen(false);
  };

  if (loading) {
    return (
      <div className="w-full h-screen bg-slate-900 flex flex-col items-center justify-center text-white">
        <div className="w-12 h-12 border-4 border-sky-400/20 border-t-sky-400 rounded-full animate-spin mb-4" />
        <h3 className="text-sm font-display font-bold tracking-wider uppercase text-sky-400">ApexRisk Securing Environs</h3>
        <span className="text-[10px] text-slate-500 font-mono mt-1">Acquiring terminal state authorization...</span>
      </div>
    );
  }

  // --- 1. RENDER PUBLIC PAGES ---
  if (currentView === "landing") {
    return (
      <div className="w-full min-h-screen">
        {/* Navigation Bar */}
        <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur border-b border-slate-800 text-white">
          <div className="max-w-7xl mx-auto px-6 h-16 flex justify-between items-center">
            <div className="flex items-center gap-2 font-display font-bold text-sm">
              <Shield className="w-5.5 h-5.5 text-sky-400" /> ApexRisk AI
            </div>
            
            <div className="flex items-center gap-4">
              <button
                id="btn-nav-login"
                onClick={() => { setCurrentView("login"); setAuthError(""); setAuthSuccess(""); }}
                className="text-xs font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                Sign In
              </button>
              <button
                id="btn-nav-register"
                onClick={() => { setCurrentView("register"); setAuthError(""); setAuthSuccess(""); }}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold transition-all shadow shadow-sky-500/10 cursor-pointer"
              >
                Register
              </button>
            </div>
          </div>
        </header>

        <LandingView
          onNavigateToLogin={() => { setCurrentView("login"); setAuthError(""); setAuthSuccess(""); }}
          onNavigateToRegister={() => { setCurrentView("register"); setAuthError(""); setAuthSuccess(""); }}
        />
      </div>
    );
  }

  if (currentView === "login" || currentView === "register" || currentView === "forgot") {
    return (
      <div className="w-full min-h-screen bg-slate-950 flex items-center justify-center p-6 relative overflow-hidden">
        {/* Decorative ambient glowing grids */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:3rem_3rem]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-sky-500/10 blur-[120px] rounded-full" />

        <div className="w-full max-w-md bg-slate-900 border border-slate-800/80 rounded-2xl p-8 relative z-10 shadow-2xl space-y-6">
          {/* Header logo */}
          <div className="flex flex-col items-center text-center space-y-2">
            <div
              onClick={() => setCurrentView("landing")}
              className="w-12 h-12 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center border border-sky-400/20 cursor-pointer hover:bg-sky-500/15 transition-all"
            >
              <Shield className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-display font-bold text-white tracking-tight">
              {currentView === "login" && "Welcome Back Officer"}
              {currentView === "register" && "Create Underwriter Profile"}
              {currentView === "forgot" && "Recovery Validation"}
            </h2>
            <p className="text-xs text-slate-400">
              {currentView === "login" && "Access ApexRisk prediction dashboards & model engines"}
              {currentView === "register" && "Establish full access credentials to evaluate applicants"}
              {currentView === "forgot" && "Reset your institutional dashboard access keys"}
            </p>
          </div>

          {/* Alert triggers */}
          {authError && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs rounded-xl font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {authSuccess && (
            <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl font-medium flex items-center gap-2">
              <Sparkles className="w-4 h-4 shrink-0 animate-pulse" />
              <span>{authSuccess}</span>
            </div>
          )}

          {/* Form blocks */}
          {currentView === "login" && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 font-mono">Email Credentials</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="input-login-email"
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="officer@fintech.com"
                    className="w-full bg-slate-950 border border-slate-800 text-white pl-10 pr-4 py-2.5 text-xs rounded-xl focus:outline-none focus:border-sky-500 transition-all font-light"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono">Access Key</label>
                  <button
                    id="btn-login-forgot"
                    type="button"
                    onClick={() => { setCurrentView("forgot"); setAuthError(""); setAuthSuccess(""); }}
                    className="text-[10px] text-sky-400 hover:underline hover:text-sky-300 transition-all cursor-pointer font-light"
                  >
                    Forgot Access Key?
                  </button>
                </div>
                <div className="relative">
                  <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="input-login-password"
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 text-white pl-10 pr-4 py-2.5 text-xs rounded-xl focus:outline-none focus:border-sky-500 transition-all"
                  />
                </div>
              </div>

              <button
                id="btn-login-submit"
                type="submit"
                disabled={authSubmitting}
                className="w-full py-3 bg-sky-500 hover:bg-sky-600 disabled:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-all shadow-lg shadow-sky-500/10 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {authSubmitting ? "Authenticating security credentials..." : "Authorize Access"} <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {currentView === "register" && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 font-mono font-bold">Officer Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="input-register-name"
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="Officer John Doe"
                    className="w-full bg-slate-950 border border-slate-800 text-white pl-10 pr-4 py-2.5 text-xs rounded-xl focus:outline-none focus:border-sky-500 transition-all font-light"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 font-mono">Registry Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="input-register-email"
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full bg-slate-950 border border-slate-800 text-white pl-10 pr-4 py-2.5 text-xs rounded-xl focus:outline-none focus:border-sky-500 transition-all font-light"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 font-mono">Access Token Key</label>
                <div className="relative">
                  <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="input-register-password"
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full bg-slate-950 border border-slate-800 text-white pl-10 pr-4 py-2.5 text-xs rounded-xl focus:outline-none focus:border-sky-500 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 font-mono">Operational Role Assigned</label>
                <select
                  id="select-register-role"
                  value={regRole}
                  onChange={(e) => setRegRole(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 text-white px-3 py-2.5 text-xs rounded-xl focus:outline-none focus:border-sky-500 bg-slate-900"
                >
                  <option value="reviewer">Lending reviewer Officer</option>
                  <option value="admin">System Admin Underwriter (Unlocks Retraining Panel)</option>
                </select>
              </div>

              <button
                id="btn-register-submit"
                type="submit"
                disabled={authSubmitting}
                className="w-full py-3 bg-sky-500 hover:bg-sky-600 disabled:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-all shadow-lg shadow-sky-500/10 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {authSubmitting ? "Assembling credentials profile..." : "Register Credentials"} <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {currentView === "forgot" && (
            <form onSubmit={handleForgot} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 font-mono">Registered Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="input-forgot-email"
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full bg-slate-950 border border-slate-800 text-white pl-10 pr-4 py-2.5 text-xs rounded-xl focus:outline-none focus:border-sky-500 transition-all font-light"
                  />
                </div>
              </div>

              <button
                id="btn-forgot-submit"
                type="submit"
                disabled={authSubmitting}
                className="w-full py-3 bg-sky-500 hover:bg-sky-600 disabled:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-all shadow-lg"
              >
                {authSubmitting ? "Validating reset map..." : "Send Verification Reset Link"}
              </button>
            </form>
          )}

          {/* Bottom toggles */}
          <div className="border-t border-slate-800/60 pt-4 flex justify-between text-xs text-slate-400 font-light">
            {currentView === "login" && (
              <>
                <span>New officer profile?</span>
                <button
                  id="btn-toggle-to-register"
                  onClick={() => { setCurrentView("register"); setAuthError(""); setAuthSuccess(""); }}
                  className="text-sky-400 font-semibold hover:underline cursor-pointer"
                >
                  Create Profile
                </button>
              </>
            )}

            {currentView === "register" && (
              <>
                <span>Already registered?</span>
                <button
                  id="btn-toggle-to-login"
                  onClick={() => { setCurrentView("login"); setAuthError(""); setAuthSuccess(""); }}
                  className="text-sky-400 font-semibold hover:underline cursor-pointer"
                >
                  Sign In
                </button>
              </>
            )}

            {currentView === "forgot" && (
              <button
                id="btn-toggle-forgot-to-login"
                onClick={() => { setCurrentView("login"); setAuthError(""); setAuthSuccess(""); }}
                className="text-sky-400 font-semibold hover:underline cursor-pointer mx-auto flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" /> Back to Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // --- 2. RENDER MAIN AUTHENTICATED PANEL WORKSPACE ---
  const activeUser = currentUser!;
  const activeTabClass = (tabId: string) =>
    activeTab === tabId ? "border-b-2 border-sky-500 text-slate-900 font-bold" : "text-slate-500 hover:text-slate-900 border-b-2 border-transparent";

  return (
    <div className="w-full min-h-screen bg-slate-50 text-slate-800 flex overflow-hidden">
      {/* 2a. COLLAPSIBLE LEFT SIDEBAR FOR DESKTOP */}
      <div className="hidden md:block shrink-0">
        <Sidebar
          currentTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab);
            if (tab !== "prediction") setActivePrediction(null);
          }}
          user={activeUser}
          onLogout={handleLogout}
          collapsed={collapsed}
          setCollapsed={setCollapsed}
        />
      </div>

      {/* 2b. MAIN COMPONENT WORKSPACE VIEW CONTAINER */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header Controls bar */}
        <header className="h-16 bg-white border-b border-slate-100 px-6 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            {/* Mobile Hamburger menu */}
            <button
              id="btn-mobile-menu"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-500 md:hidden cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-sky-500 md:hidden" />
              <span className="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase">
                {activeTab === "dashboard" && "Overview Metrics"}
                {activeTab === "prediction" && "Credit Evaluator"}
                {activeTab === "history" && "Audit Log history"}
                {activeTab === "analytics" && "Cognitive Analytics"}
                {activeTab === "profile" && "Security credentials"}
                {activeTab.startsWith("admin") && "Admin Terminal"}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              id="btn-logout-header"
              onClick={handleLogout}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-rose-50 text-slate-500 hover:text-rose-600 transition-all cursor-pointer hidden sm:inline-flex"
              title="Sign Out Session"
            >
              <LogOut className="w-4 h-4" />
            </button>
            
            <div className="flex items-center gap-2 border-l border-slate-100 pl-4">
              <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-display font-semibold text-xs flex items-center justify-center shrink-0 shadow-sm">
                {activeUser.name.charAt(0)}
              </div>
              <span className="text-xs font-semibold text-slate-800 hidden lg:inline">{activeUser.name}</span>
            </div>
          </div>
        </header>

        {/* Inner dynamic content block with scrollbars */}
        <div className="flex-1 overflow-y-auto bg-slate-50/50 dashboard-gradient">
          {activeTab === "dashboard" && (
            <DashboardView
              user={activeUser}
              onTabChange={(tab) => {
                setActiveTab(tab);
                setActivePrediction(null);
              }}
              onSelectReport={handleSelectReport}
            />
          )}

          {activeTab === "prediction" && (
            activePrediction ? (
              <PredictionResultView
                record={activePrediction}
                onBackToForm={() => setActivePrediction(null)}
                onGoToHistory={() => {
                  setActivePrediction(null);
                  setActiveTab("history");
                }}
              />
            ) : (
              <PredictionFormView
                onPredictionSuccess={(record) => setActivePrediction(record)}
              />
            )
          )}

          {activeTab === "history" && (
            <HistoryView onSelectReport={handleSelectReport} />
          )}

          {activeTab === "analytics" && <AnalyticsView />}

          {activeTab === "profile" && (
            <ProfileView
              user={activeUser}
              onProfileUpdate={(updatedUser) => setCurrentUser(updatedUser)}
              onLogout={handleLogout}
            />
          )}

          {activeTab.startsWith("admin") && (
            <AdminView currentUser={activeUser} />
          )}
        </div>
      </div>

      {/* 2c. MOBILE SLIDE-OUT NAVIGATION OVERLAY MENU */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden flex md:hidden">
          {/* Backdrop blur overlay */}
          <div
            className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />

          {/* Drawer Panel */}
          <div className="relative w-64 max-w-xs bg-slate-900 text-slate-300 h-full shadow-2xl flex flex-col justify-between p-4 z-10 animate-slide-in">
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-slate-850 pb-4">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-sky-400" />
                  <span className="font-display font-bold text-white text-sm">ApexRisk Mobile</span>
                </div>
                <button
                  id="btn-close-mobile-menu"
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded-lg border border-slate-800 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Navigation list */}
              <nav className="space-y-1">
                {[
                  { id: "dashboard", label: "Overview Metrics" },
                  { id: "prediction", label: "New Prediction" },
                  { id: "history", label: "History Log" },
                  { id: "analytics", label: "Analytics Hub" },
                  { id: "profile", label: "My Profile" },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                      if (item.id !== "prediction") setActivePrediction(null);
                    }}
                    className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                      activeTab === item.id ? "bg-sky-500 text-white" : "text-slate-400 hover:bg-slate-800"
                    }`}
                  >
                    {item.label}
                  </button>
                ))}

                {activeUser.role === "admin" && (
                  <div className="pt-4 border-t border-slate-800 space-y-1">
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block px-3.5 mb-1">
                      System Control
                    </span>
                    <button
                      onClick={() => {
                        setActiveTab("admin-models");
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                        activeTab === "admin-models" ? "bg-amber-500 text-slate-950" : "text-slate-400 hover:bg-slate-800"
                      }`}
                    >
                      Model Optimization
                    </button>
                    <button
                      onClick={() => {
                        setActiveTab("admin-users");
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                        activeTab === "admin-users" ? "bg-amber-500 text-slate-950" : "text-slate-400 hover:bg-slate-800"
                      }`}
                    >
                      User Control
                    </button>
                  </div>
                )}
              </nav>
            </div>

            <button
              id="btn-mobile-logout"
              onClick={() => {
                setMobileMenuOpen(false);
                handleLogout();
              }}
              className="w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold hover:bg-rose-500/10 hover:text-rose-400 text-slate-400 transition-all flex items-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" /> Sign Out Session
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
